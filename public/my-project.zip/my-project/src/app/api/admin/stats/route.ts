import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const [totalDeals, pendingDeals, completedDeals, totalUsers, totalAmount] =
      await Promise.all([
        db.deal.count(),
        db.deal.count({ where: { status: 'created' } }),
        db.deal.count({ where: { status: 'completed' } }),
        db.user.count(),
        db.deal.aggregate({ _sum: { amount: true } }),
      ])

    return NextResponse.json({
      totalDeals,
      pendingDeals,
      completedDeals,
      totalUsers,
      totalAmount: totalAmount._sum.amount || 0,
    })
  } catch {
    return NextResponse.json(
      { error: 'স্ট্যাটস লোড করতে সমস্যা হয়েছে' },
      { status: 500 }
    )
  }
}