import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { userId, role } = await req.json()

    if (!userId || !role) {
      return NextResponse.json(
        { error: 'ইউজার আইডি ও ভূমিকা প্রদান করুন' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({ where: { id: userId } })
    if (!user) {
      return NextResponse.json(
        { error: 'ইউজার পাওয়া যায়নি' },
        { status: 404 }
      )
    }

    await db.user.update({
      where: { id: userId },
      data: { role },
    })

    return NextResponse.json({
      success: true,
      message: 'ইউজারের ভূমিকা সফলভাবে পরিবর্তন করা হয়েছে',
    })
  } catch {
    return NextResponse.json(
      { error: 'ভূমিকা পরিবর্তনে সমস্যা হয়েছে' },
      { status: 500 }
    )
  }
}