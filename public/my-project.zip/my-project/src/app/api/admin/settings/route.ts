import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const settingKeys = [
  'platform_name',
  'fee_percentage',
  'min_deal_amount',
  'max_deal_amount',
  'support_number',
  'payment_theme_color',
]

export async function GET() {
  try {
    const rows = await db.platformSetting.findMany({
      where: { key: { in: settingKeys } },
    })

    const map: Record<string, string> = {}
    for (const r of rows) {
      map[r.key] = r.value
    }

    return NextResponse.json({
      platform_name: map.platform_name || 'আমার ডিল',
      fee_percentage: map.fee_percentage || '3',
      min_deal_amount: map.min_deal_amount || '100',
      max_deal_amount: map.max_deal_amount || '10000000',
      support_number: map.support_number || '',
      payment_theme_color: map.payment_theme_color || '#A3E635',
    })
  } catch {
    return NextResponse.json(
      { error: 'সেটিংস লোড করতে সমস্যা হয়েছে' },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()

    // Upsert each provided key
    for (const key of settingKeys) {
      if (body[key] !== undefined) {
        await db.platformSetting.upsert({
          where: { key },
          update: { value: String(body[key]) },
          create: { key, value: String(body[key]) },
        })
      }
    }

    return NextResponse.json({
      success: true,
      message: 'সেটিংস সফলভাবে সংরক্ষণ করা হয়েছে',
    })
  } catch {
    return NextResponse.json(
      { error: 'সেটিংস সংরক্ষণে সমস্যা হয়েছে' },
      { status: 500 }
    )
  }
}