import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { identifier, password } = await req.json()

    if (!identifier || !password) {
      return NextResponse.json(
        { error: 'ইমেইল/মোবাইল এবং পাসওয়ার্ড দিন' },
        { status: 400 }
      )
    }

    const user = await db.user.findFirst({
      where: {
        OR: [{ email: identifier }, { phone: identifier }],
        password,
      },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'ইমেইল/মোবাইল বা পাসওয়ার্ড ভুল হয়েছে' },
        { status: 401 }
      )
    }

    return NextResponse.json({
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
    })
  } catch {
    return NextResponse.json(
      { error: 'লগইনে সমস্যা হয়েছে' },
      { status: 500 }
    )
  }
}