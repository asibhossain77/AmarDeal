import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { title, role, amount, partyEmail, terms, userId } = await req.json()

    if (!title || !amount || !userId) {
      return NextResponse.json(
        { error: 'প্রয়োজনীয় তথ্য প্রদান করুন' },
        { status: 400 }
      )
    }

    if (amount <= 0) {
      return NextResponse.json(
        { error: 'পরিমাণ অবশ্যই শূন্যের বেশি হতে হবে' },
        { status: 400 }
      )
    }

    // Count existing deals to generate a sequential deal number
    const dealCount = await db.deal.count()
    const dealNumber = String(dealCount + 1001)

    const deal = await db.deal.create({
      data: {
        title,
        amount,
        status: 'created',
        buyerId: userId,
        creatorId: userId,
      },
    })

    return NextResponse.json({
      id: deal.id,
      dealNumber,
      title: deal.title,
      amount: deal.amount,
      status: deal.status,
      createdAt: deal.createdAt,
    })
  } catch {
    return NextResponse.json(
      { error: 'ডিল তৈরিতে সমস্যা হয়েছে' },
      { status: 500 }
    )
  }
}