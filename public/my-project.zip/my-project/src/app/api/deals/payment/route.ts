import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { dealId, paymentMethodId, senderNumber, transactionId, amount } = body

    if (!dealId || !senderNumber || !transactionId) {
      return NextResponse.json(
        { error: 'সকল তথ্য প্রদান করুন' },
        { status: 400 }
      )
    }

    // Update deal status to payment_pending
    const deal = await db.deal.update({
      where: { id: dealId },
      data: { status: 'payment_pending' },
    })

    return NextResponse.json({
      success: true,
      message: 'পেমেন্ট সফলভাবে জমা হয়েছে',
      deal,
    })
  } catch {
    return NextResponse.json(
      { error: 'পেমেন্ট জমা করতে সমস্যা হয়েছে' },
      { status: 500 }
    )
  }
}