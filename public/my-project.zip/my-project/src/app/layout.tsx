import type { Metadata } from "next";
import { Hind_Siliguri } from "next/font/google";
import { ThemeProvider } from "next-themes";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const hindSiliguri = Hind_Siliguri({
  variable: "--font-hind-siliguri",
  subsets: ["bengali", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "আমার ডিল - নিরাপদ অনলাইন লেনদেন",
  description:
    "আমার ডিল দিয়ে নিরাপদে অনলাইনে লেনদেন করুন। এসক্রো সার্ভিসের মাধ্যমে আপনার টাকা ও পণ্য সুরক্ষিত রাখুন।",
  keywords: [
    "এসক্রো",
    "নিরাপদ লেনদেন",
    "অনলাইন পেমেন্ট",
    "বাংলাদেশ",
    "আমার ডিল",
  ],
  authors: [{ name: "আমার ডিল" }],
  openGraph: {
    title: "আমার ডিল - নিরাপদ অনলাইন লেনদেন",
    description:
      "এসক্রো সার্ভিসের মাধ্যমে নিরাপদে অনলাইনে লেনদেন করুন।",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="bn" suppressHydrationWarning>
      <body className={`${hindSiliguri.variable} font-sans antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}