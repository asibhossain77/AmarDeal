'use client';

import { useAppStore } from '@/lib/store';
import { Navbar } from '@/components/landing/navbar';
import { Hero } from '@/components/landing/hero';
import { HowItWorks } from '@/components/landing/how-it-works';
import { TrustSecurity } from '@/components/landing/trust-security';
import { Footer } from '@/components/landing/footer';
import { AuthView } from '@/components/auth/auth-view';
import { DashboardView } from '@/components/dashboard/dashboard-view';
import { AdminView } from '@/components/admin/admin-view';
import { SellerView } from '@/components/seller/seller-view';

function LandingView() {
  return (
    <>
      <main className="flex-1">
        <Hero />
        <HowItWorks />
        <TrustSecurity />
      </main>
      <Footer />
    </>
  );
}

export default function Home() {
  const view = useAppStore((s) => s.view);

  return (
    <div className="min-h-screen flex flex-col !bg-[#F2F4F7] dark:!bg-[#09090b]">
      <Navbar />
      {view === 'auth' && <AuthView />}
      {view === 'dashboard' && <DashboardView />}
      {view === 'seller' && <SellerView />}
      {view === 'admin' && <AdminView />}
      {view === 'landing' && <LandingView />}
    </div>
  );
}