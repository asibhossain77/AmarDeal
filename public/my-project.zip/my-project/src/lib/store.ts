import { create } from 'zustand'

export type AppView = 'landing' | 'auth' | 'dashboard' | 'seller' | 'admin'
export type DashboardPanel = 'overview' | 'new-deal' | 'deal-detail' | 'payment'
export type SellerPanel = 'overview' | 'incoming-deals' | 'active-deals' | 'deal-detail' | 'my-products'
export type AdminPanel = 'dashboard' | 'payment-verify' | 'all-deals' | 'users' | 'settings' | 'payment-methods'

export type UserRole = 'user' | 'seller' | 'admin'

interface UserInfo {
  id: string
  name: string
  email: string
  phone: string
  role: UserRole
}

interface DealInfo {
  id: string
  title: string
  category: string
  amount: number
  feePayer: string
  status: string
  createdAt: string
}

interface AppState {
  view: AppView
  user: UserInfo | null
  sidebarOpen: boolean
  dashboardPanel: DashboardPanel
  sellerPanel: SellerPanel
  adminPanel: AdminPanel
  activeDeal: DealInfo | null
  setView: (view: AppView) => void
  setUser: (user: UserInfo | null) => void
  logout: () => void
  setSidebarOpen: (open: boolean) => void
  setDashboardPanel: (panel: DashboardPanel) => void
  setSellerPanel: (panel: SellerPanel) => void
  setAdminPanel: (panel: AdminPanel) => void
  setActiveDeal: (deal: DealInfo | null) => void
}

export const useAppStore = create<AppState>((set) => ({
  view: 'landing',
  user: null,
  sidebarOpen: false,
  dashboardPanel: 'overview',
  sellerPanel: 'overview',
  adminPanel: 'dashboard',
  activeDeal: null,
  setView: (view) => set({ view, sidebarOpen: false }),
  setUser: (user) => {
    if (!user) return set({ user: null, view: 'landing', sidebarOpen: false, dashboardPanel: 'overview', sellerPanel: 'overview', adminPanel: 'dashboard', activeDeal: null })
    if (user.role === 'admin') return set({ user, view: 'admin', sidebarOpen: false, adminPanel: 'dashboard' })
    if (user.role === 'seller') return set({ user, view: 'seller', sidebarOpen: false, sellerPanel: 'overview' })
    return set({ user, view: 'dashboard', sidebarOpen: false, dashboardPanel: 'overview' })
  },
  logout: () => set({ user: null, view: 'landing', sidebarOpen: false, dashboardPanel: 'overview', sellerPanel: 'overview', adminPanel: 'dashboard', activeDeal: null }),
  setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
  setDashboardPanel: (dashboardPanel) => set({ dashboardPanel }),
  setSellerPanel: (sellerPanel) => set({ sellerPanel }),
  setAdminPanel: (adminPanel) => set({ adminPanel, sidebarOpen: false }),
  setActiveDeal: (activeDeal) => set({ activeDeal }),
}))