import { Separator } from '@/components/ui/separator';

const footerLinks = {
  সেবা: [
    { label: 'কিভাবে কাজ করে', href: '#how-it-works' },
    { label: 'ফি কাঠামো', href: '#fees' },
    { label: 'নিরাপত্তা', href: '#features' },
    { label: 'FAQ', href: '#faq' },
  ],
  কোম্পানি: [
    { label: 'আমাদের সম্পর্কে', href: '#about' },
    { label: 'যোগাযোগ', href: '#contact' },
    { label: 'গোপনীয়তা নীতি', href: '#privacy' },
    { label: 'শর্তাবলী', href: '#terms' },
  ],
};

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-card">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <a href="/" className="mb-4 flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
                <span className="text-base font-bold leading-none text-primary-foreground">
                  আ
                </span>
              </div>
              <span className="text-lg font-bold tracking-tight">
                আমার ডিল
              </span>
            </a>
            <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">
              আমার ডিল বাংলাদেশের সবচেয়ে বিশ্বস্ত এসক্রো প্ল্যাটফর্ম।
              আমরা নিরাপদ অনলাইন লেনদেন নিশ্চিত করি যাতে আপনি
              নিশ্চিন্তে কেনাবেচা করতে পারেন।
            </p>
          </div>

          {/* Links Columns */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="mb-4 text-sm font-semibold">{category}</h3>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <Separator className="my-8 bg-border/50" />

        {/* Copyright */}
        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} আমার ডিল। সর্বস্বত্ব সংরক্ষিত।
          </p>
          <p className="text-xs text-muted-foreground">
            বাংলাদেশে তৈরি
          </p>
        </div>
      </div>
    </footer>
  );
}