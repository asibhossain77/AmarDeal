'use client';

import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const escrowSteps = [
  {
    num: '১',
    color: 'bg-primary',
    title: 'টাকা জমা',
    subtitle: 'bKash / Nagad / Bank',
  },
  {
    num: '২',
    color: 'bg-teal-400 dark:bg-teal-500',
    title: 'মধ্যস্থতা',
    subtitle: 'অ্যাডমিন যাচাই করেন',
  },
  {
    num: '৩',
    color: 'bg-lime-300 dark:bg-lime-400',
    title: 'টাকা রিলিজ',
    subtitle: 'বিক্রেতা পান বা রিফান্ড',
  },
];

function EscrowStatusCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2, ease: 'easeOut' }}
      className="order-2 md:order-1"
    >
      <div className="relative mx-auto w-full max-w-sm md:mx-0 md:max-w-none">
        {/* Green gradient blob behind the card for visible glassmorphism */}
        <div className="pointer-events-none absolute -inset-4 -left-8 rounded-3xl bg-gradient-to-br from-lime-300/25 via-primary/15 to-teal-200/10 blur-2xl dark:from-lime-400/15 dark:via-primary/10 dark:to-teal-400/5" />
        <div className="relative rounded-2xl border !border-white/60 !bg-white/40 p-6 shadow-2xl !backdrop-blur-xl dark:!border-zinc-800/50 dark:!bg-zinc-900/50 dark:!backdrop-blur-xl dark:glow-lime sm:p-7">
          {/* Card Header */}
          <div className="mb-6 flex items-center justify-between">
            <h3 className="text-sm font-semibold tracking-wide text-foreground">
              এসক্রো স্ট্যাটাস
            </h3>
            <span className="rounded-full bg-primary/15 px-3 py-1 text-xs font-semibold text-primary">
              সুরক্ষিত
            </span>
          </div>

          {/* 3-Step Progress List */}
          <div>
            {escrowSteps.map((step, i) => (
              <div key={step.num}>
                <div className="flex items-start gap-3.5">
                  <div
                    className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold text-primary-foreground ${step.color}`}
                  >
                    {step.num}
                  </div>
                  <div className="min-w-0 pb-5 pt-0.5">
                    <p className="text-sm font-semibold text-foreground">
                      {step.title}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {step.subtitle}
                    </p>
                  </div>
                </div>
                {i < escrowSteps.length - 1 && (
                  <div className="ml-3.5 h-4 w-px border-l border-dashed border-border" />
                )}
              </div>
            ))}
          </div>

          {/* Divider */}
          <div className="border-t border-border/60" />

          {/* Amount */}
          <div className="py-4 text-center">
            <p className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
              ৳৫০,০০০<span className="text-lg">.০০</span>
            </p>
            <p className="mt-1 text-[11px] text-muted-foreground">
              উদাহরণ এসক্রো পরিমাণ
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      {/* Background aura - subtle parrot green radial blur */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute top-1/4 right-1/4 h-[500px] w-[500px] rounded-full bg-primary/[0.07] blur-[120px] dark:bg-primary/[0.06]" />
        <div className="absolute bottom-0 left-1/3 h-[400px] w-[400px] rounded-full bg-primary/[0.04] blur-[100px] dark:bg-primary/[0.04]" />
      </div>

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex min-h-[calc(100vh-4rem)] items-center py-16 sm:py-20">
          <div className="grid w-full items-center gap-10 lg:grid-cols-2 lg:gap-16">
            {/* Text Content Column — Right on desktop / TOP on mobile */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="order-1 flex flex-col items-center text-center md:order-2 md:items-start md:text-left"
            >
              {/* Pill Badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1, duration: 0.4 }}
                className="mb-6 inline-flex items-center justify-center gap-2 self-center md:self-auto rounded-full bg-primary/15 px-4 py-1.5"
              >
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-primary" />
                </span>
                <span className="text-xs font-semibold tracking-wide text-primary">
                  নিরাপদ অনলাইন লেনদেন
                </span>
              </motion.div>

              {/* Main Heading */}
              <h1 className="mb-5 text-center text-3xl font-bold leading-[1.2] tracking-tight sm:text-4xl md:text-left md:text-5xl lg:text-[3.4rem]">
                আপনার টাকা,
                <br />
                <span className="glow-text-lime text-primary">আমাদের দায়িত্ব</span>
              </h1>

              {/* Subtitle */}
              <p className="mx-auto mb-8 max-w-md text-center text-base leading-relaxed text-muted-foreground md:mx-0 md:text-left sm:text-[17px]">
                আমার ডিল-এ ক্রেতা ও বিক্রেতার মধ্যে নিরাপদ এসক্রো সেবা।
                টাকা জমা থেকে রিলিজ পর্যন্ত — সব কিছু স্বচ্ছ ও নিরাপদ।
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col items-center gap-3 sm:flex-row sm:justify-center md:items-start md:justify-start">
                <Button
                  size="lg"
                  className="gap-2.5 rounded-xl px-7 text-[15px] font-semibold shadow-lg shadow-primary/25 dark:glow-lime"
                >
                  এখনই শুরু করুন
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <a
                  href="#features"
                  className="inline-flex items-center gap-1.5 rounded-xl px-7 py-3 text-[15px] font-medium text-muted-foreground transition-colors hover:text-foreground"
                >
                  আরও জানুন
                  <ArrowRight className="h-3.5 w-3.5" />
                </a>
              </div>
            </motion.div>

            {/* Escrow Status Card Column — Left on desktop / BOTTOM on mobile */}
            <EscrowStatusCard />
          </div>
        </div>
      </div>
    </section>
  );
}