'use client';

import { useState, useSyncExternalStore } from 'react';
import { useTheme } from 'next-themes';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  Menu,
  Sun,
  Moon,
  LogIn,
  LayoutDashboard,
  FilePlus,
  LogOut,
  } from 'lucide-react';

const emptySubscribe = () => () => {};

function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);

  if (!mounted) {
    return (
      <button className="flex h-9 w-9 items-center justify-center rounded-lg" aria-label="থিম পরিবর্তন">
        <span className="h-4 w-4" />
      </button>
    );
  }

  return (
    <button
      className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      aria-label="থিম পরিবর্তন"
    >
      {theme === 'dark' ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
    </button>
  );
}

export function Navbar() {
  const [open, setOpen] = useState(false);
  const { view, user, logout, setView, setDashboardPanel, setAdminPanel } = useAppStore();
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);

  const isAdmin = view === 'admin';
  const isAuth = view === 'auth' || view === 'dashboard';
  const isDashboard = view === 'dashboard' && user;

  const handleLogout = () => {
    logout();
    setOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/70 backdrop-blur-xl">
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand Logo */}
        <button
          onClick={() => {
            if (isDashboard) setDashboardPanel('overview');
            else if (isAdmin) setAdminPanel('dashboard');
            else if (isAuth) setView('landing');
          }}
          className="flex items-center gap-2.5"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <span className="text-base font-bold leading-none text-primary-foreground">আ</span>
          </div>
          <span className="text-lg font-bold tracking-tight text-foreground">আমার ডিল</span>
        </button>

        {/* ── Desktop Nav: Landing ── */}
        {!isAuth && !isAdmin && (
          <>
            <div className="hidden items-center gap-1 md:flex">
              <a href="#features" className="rounded-lg px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground hover:bg-accent">
                বৈশিষ্ট্য
              </a>
            </div>
            <div className="hidden items-center gap-2 md:flex">
              <ThemeToggle />
              <Button size="sm" onClick={() => setView('auth')} className="gap-2 rounded-lg font-medium shadow-md shadow-primary/20">
                <LogIn className="h-4 w-4" />
                লগইন / নিবন্ধন
              </Button>
            </div>
          </>
        )}

        {/* ── Desktop Nav: Dashboard ── */}
        {isDashboard && mounted && (
          <div className="hidden items-center gap-1 md:flex">
            <button
              onClick={() => setDashboardPanel('overview')}
              className="flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground hover:bg-accent"
            >
              <LayoutDashboard className="h-4 w-4" />
              ড্যাশবোর্ড
            </button>
            <button
              onClick={() => setDashboardPanel('new-deal')}
              className="flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium text-primary bg-primary/10 transition-colors hover:bg-primary/15"
            >
              <FilePlus className="h-4 w-4" />
              নতুন ডিল
            </button>
            <div className="mx-1 h-5 w-px bg-border/60" />
            <ThemeToggle />
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/15 text-xs font-bold text-primary">
              {user?.name?.charAt(0) || 'ই'}
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-destructive hover:bg-destructive/10"
            >
              <LogOut className="h-4 w-4" />
              লগআউট
            </button>
          </div>
        )}

        {/* ── Desktop Nav: Admin ── */}
        {isAdmin && mounted && (
          <div className="hidden items-center gap-2 md:flex">
            <ThemeToggle />
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/15 text-xs font-bold text-primary">A</div>
            <button
              onClick={() => setView('dashboard')}
              className="flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground hover:bg-accent"
            >
              <LogOut className="h-4 w-4" />
              এক্সিট অ্যাডমিন
            </button>
          </div>
        )}

        {/* ── Mobile Menu ── */}
        <div className="flex items-center gap-2 md:hidden">
          <ThemeToggle />
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <button className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground" aria-label="মেনু খুলুন">
                <Menu className="h-5 w-5" />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <nav className="flex flex-col gap-1 pt-8">
                {isDashboard && (
                  <>
                    <button onClick={() => { setDashboardPanel('overview'); setOpen(false); }} className="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground hover:bg-accent">
                      <LayoutDashboard className="h-4 w-4" /> ড্যাশবোর্ড
                    </button>
                    <button onClick={() => { setDashboardPanel('new-deal'); setOpen(false); }} className="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-primary bg-primary/10">
                      <FilePlus className="h-4 w-4" /> নতুন ডিল
                    </button>
                    <div className="mt-4 border-t border-border pt-4">
                      <button onClick={handleLogout} className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-destructive hover:bg-destructive/10">
                        <LogOut className="h-4 w-4" /> লগআউট
                      </button>
                    </div>
                  </>
                )}
                {isAdmin && (
                  <>
                    <button onClick={() => { setView('dashboard'); setOpen(false); }} className="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground hover:bg-accent">
                      <LayoutDashboard className="h-4 w-4" /> ইউজার ড্যাশবোর্ডে ফিরুন
                    </button>
                  </>
                )}
                {!isAuth && !isAdmin && (
                  <>
                    <a href="#features" onClick={() => setOpen(false)} className="rounded-lg px-4 py-3 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground hover:bg-accent">
                      বৈশিষ্ট্য
                    </a>
                    <div className="mt-4 border-t border-border pt-4">
                      <Button onClick={() => { setOpen(false); setView('auth'); }} className="w-full gap-2 rounded-lg font-medium">
                        <LogIn className="h-4 w-4" /> লগইন / নিবন্ধন
                      </Button>
                    </div>
                  </>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}