'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import {
  ArrowLeft,
  Phone,
  Hash,
  ShieldCheck,
  CreditCard,
  Building2,
  Wallet,
  Loader2,
} from 'lucide-react';

/* ─── Types ─── */
interface PaymentMethod {
  id: string;
  name: string;
  accountNumber: string;
  accountType: string;
}

interface PaymentSettings {
  paymentThemeColor: string;
  feePercentage: number;
  platformName: string;
}

/* ─── Color Utility ─── */
function getContrastColor(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.6 ? '#18181b' : '#ffffff';
}

/* ─── Method icon helper ─── */
function getMethodIcon(name: string) {
  const lower = name.toLowerCase();
  if (lower.includes('bkash')) return Wallet;
  if (lower.includes('nagad')) return CreditCard;
  if (lower.includes('rocket')) return Wallet;
  if (lower.includes('bank')) return Building2;
  return CreditCard;
}

/* ─── Animation Variants ─── */
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.07 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 18 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' } },
};

/* ─── Component ─── */
export function UserPaymentView() {
  const activeDeal = useAppStore((s) => s.activeDeal);
  const setDashboardPanel = useAppStore((s) => s.setDashboardPanel);

  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [themeColor, setThemeColor] = useState<string>('#A3E635');
  const [feePercentage, setFeePercentage] = useState<number>(2.5);
  const [loading, setLoading] = useState(true);
  const [senderNumber, setSenderNumber] = useState('');
  const [txnId, setTxnId] = useState('');
  const [submitting, setSubmitting] = useState(false);

  /* ─── Fetch data ─── */
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [methodsRes, settingsRes] = await Promise.all([
        fetch('/api/payment-methods'),
        fetch('/api/payment-settings'),
      ]);

      if (methodsRes.ok) {
        const methodsData = await methodsRes.json();
        setMethods(methodsData);
        if (methodsData.length > 0 && !selectedId) {
          setSelectedId(methodsData[0].id);
        }
      }

      if (settingsRes.ok) {
        const settingsData: PaymentSettings = await settingsRes.json();
        setThemeColor(settingsData.paymentThemeColor || '#A3E635');
        setFeePercentage(settingsData.feePercentage ?? 2.5);
      }
    } catch {
      toast.error('পেমেন্ট তথ্য লোড করতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  /* ─── Derived ─── */
  const selectedMethod = methods.find((m) => m.id === selectedId);
  const amount = activeDeal?.amount ?? 0;
  const fee = Math.round((amount * feePercentage) / 100);
  const totalAmount = amount + fee;
  const contrastColor = getContrastColor(themeColor);

  const canConfirm =
    selectedId !== '' && senderNumber.trim() !== '' && txnId.trim() !== '';

  /* ─── Handlers ─── */
  const handleConfirm = async () => {
    if (!canConfirm || !activeDeal || !selectedMethod) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/deals/payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dealId: activeDeal.id,
          paymentMethodId: selectedMethod.id,
          senderNumber: senderNumber.trim(),
          transactionId: txnId.trim(),
          amount: totalAmount,
        }),
      });

      if (res.ok) {
        toast.success('পেমেন্ট সফলভাবে জমা হয়েছে!');
        setDashboardPanel('deal-detail');
      } else {
        const data = await res.json().catch(() => ({}));
        toast.error(data.error || 'পেমেন্ট জমা করতে সমস্যা হয়েছে');
      }
    } catch {
      toast.error('নেটওয়ার্ক সমস্যা। আবার চেষ্টা করুন।');
    } finally {
      setSubmitting(false);
    }
  };

  /* ─── No active deal ─── */
  if (!activeDeal) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 py-20">
        <CreditCard className="h-12 w-12 text-muted-foreground/50" />
        <p className="text-lg font-medium text-muted-foreground">
          কোনো সক্রিয় ডিল নেই
        </p>
        <Button
          variant="outline"
          onClick={() => setDashboardPanel('deal-detail')}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          ফিরে যান
        </Button>
      </div>
    );
  }

  /* ─── Loading skeleton ─── */
  if (loading) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-muted animate-pulse" />
          <div className="space-y-2">
            <div className="h-6 w-40 rounded bg-muted animate-pulse" />
            <div className="h-4 w-64 rounded bg-muted animate-pulse" />
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 rounded-2xl bg-white dark:bg-zinc-900 shadow-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="flex flex-col gap-6"
    >
      {/* ── Top Section: Back Button + Title ── */}
      <motion.div variants={itemVariants} className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setDashboardPanel('deal-detail')}
          className="h-10 w-10 rounded-xl hover:bg-accent"
          aria-label="ফিরে যান"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            পেমেন্ট করুন
          </h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            পেমেন্ট মেথড নির্বাচন করুন এবং তথ্য প্রদান করুন
          </p>
        </div>
      </motion.div>

      {/* ── Payment Method Selection Grid ── */}
      {methods.length > 0 && (
        <motion.div variants={itemVariants}>
          <h2 className="mb-3 text-base font-semibold text-foreground">
            পেমেন্ট মেথড নির্বাচন করুন
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {methods.map((method) => {
              const Icon = getMethodIcon(method.name);
              const isSelected = method.id === selectedId;

              return (
                <motion.button
                  key={method.id}
                  type="button"
                  onClick={() => setSelectedId(method.id)}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative text-left rounded-2xl bg-white dark:bg-zinc-900 shadow-lg p-4 border-2 transition-colors duration-200 cursor-pointer"
                  style={{
                    borderColor: isSelected ? themeColor : 'transparent',
                    backgroundColor: isSelected
                      ? `color-mix(in srgb, ${themeColor} 8%, white)`
                      : undefined,
                  }}
                >
                  {/* Mobile-friendly: force light bg in dark mode when selected */}
                  {isSelected && (
                    <style>{`
                      @media (prefers-color-scheme: dark) {
                        .dark .pm-card-selected-${method.id.replace(/[^a-zA-Z0-9]/g, '')} {
                          background-color: color-mix(in srgb, ${themeColor} 10%, #18181b) !important;
                        }
                      }
                    `}</style>
                  )}

                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div
                        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
                        style={{
                          backgroundColor: isSelected
                            ? `color-mix(in srgb, ${themeColor} 18%, transparent)`
                            : 'hsl(var(--muted))',
                          color: isSelected ? themeColor : 'hsl(var(--muted-foreground))',
                        }}
                      >
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-base font-bold text-foreground truncate">
                          {method.name}
                        </p>
                        <p className="mt-0.5 text-sm text-muted-foreground font-mono tracking-wide">
                          {method.accountNumber}
                        </p>
                      </div>
                    </div>
                    <Badge
                      className={`shrink-0 border-0 text-xs font-medium ${
                        method.accountType === 'merchant'
                          ? 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400'
                          : 'bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-400'
                      }`}
                    >
                      {method.accountType === 'merchant' ? 'মার্চেন্ট' : 'পার্সোনাল'}
                    </Badge>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </motion.div>
      )}

      {methods.length === 0 && !loading && (
        <motion.div variants={itemVariants} className="bg-white dark:bg-zinc-900 shadow-lg rounded-2xl p-6 text-center">
          <CreditCard className="mx-auto h-10 w-10 text-muted-foreground/50 mb-3" />
          <p className="text-sm text-muted-foreground">
            কোনো সক্রিয় পেমেন্ট মেথড পাওয়া যায়নি
          </p>
        </motion.div>
      )}

      {/* ── Payment Instructions Section ── */}
      <AnimatePresence>
        {selectedMethod && (
          <motion.div
            key={selectedMethod.id}
            variants={itemVariants}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.3 }}
            className="bg-white dark:bg-zinc-900 shadow-lg rounded-2xl p-5 border-l-4"
            style={{ borderLeftColor: themeColor }}
          >
            <h2 className="mb-4 text-base font-semibold text-foreground flex items-center gap-2">
              <CreditCard className="h-4 w-4" style={{ color: themeColor }} />
              পেমেন্ট তথ্য
            </h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">পরিমাণ</span>
                <span className="text-base font-semibold text-foreground">
                  ৳{amount.toLocaleString('bn-BD')}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">প্ল্যাটফর্ম ফি ({feePercentage}%)</span>
                <span className="text-base font-semibold text-foreground">
                  ৳{fee.toLocaleString('bn-BD')}
                </span>
              </div>
              <div className="border-t border-border/60 pt-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-muted-foreground">মোট পরিমাণ</span>
                  <span
                    className="text-xl font-bold"
                    style={{ color: themeColor }}
                  >
                    ৳{totalAmount.toLocaleString('bn-BD')}
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-muted/50 px-4 py-3">
                <span className="text-sm text-muted-foreground">পেমেন্ট পাঠান</span>
                <span className="text-base font-bold font-mono tracking-wide text-foreground">
                  {selectedMethod.accountNumber}
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Input Section ── */}
      <motion.div
        variants={itemVariants}
        className="bg-white dark:bg-zinc-900 shadow-lg rounded-2xl p-5"
      >
        <h2 className="mb-4 text-base font-semibold text-foreground">
          আপনার পেমেন্ট তথ্য
        </h2>
        <div className="space-y-4">
          {/* Sender Number */}
          <div className="space-y-2">
            <Label htmlFor="senderNumber" className="text-sm font-medium text-foreground">
              প্রেরকের নম্বর
            </Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input
                id="senderNumber"
                type="tel"
                placeholder="আপনার bKash/Nagad/Rocket নম্বর"
                value={senderNumber}
                onChange={(e) => setSenderNumber(e.target.value)}
                className="pl-10 h-11 rounded-xl border-border/60 focus-visible:ring-1"
              />
            </div>
          </div>

          {/* Transaction ID */}
          <div className="space-y-2">
            <Label htmlFor="txnId" className="text-sm font-medium text-foreground">
              ট্রানজেকশন আইডি (TxnID)
            </Label>
            <div className="relative">
              <Hash className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input
                id="txnId"
                type="text"
                placeholder="ট্রানজেকশন আইডি লিখুন"
                value={txnId}
                onChange={(e) => setTxnId(e.target.value)}
                className="pl-10 h-11 rounded-xl border-border/60 focus-visible:ring-1"
              />
            </div>
          </div>
        </div>
      </motion.div>

      {/* ── Confirm Payment Button ── */}
      <motion.div variants={itemVariants}>
        <Button
          onClick={handleConfirm}
          disabled={!canConfirm || submitting}
          className="w-full h-12 rounded-xl text-base font-bold gap-2.5 shadow-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          style={{
            backgroundColor: canConfirm ? themeColor : 'hsl(var(--muted))',
            color: canConfirm ? contrastColor : 'hsl(var(--muted-foreground))',
          }}
        >
          {submitting ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <ShieldCheck className="h-5 w-5" />
          )}
          {submitting ? 'জমা হচ্ছে...' : 'কনফার্ম পেমেন্ট'}
        </Button>
      </motion.div>
    </motion.div>
  );
}