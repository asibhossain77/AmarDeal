'use client';

import { useState, useCallback, useSyncExternalStore } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, FileText, PlusCircle } from 'lucide-react';
import { toast } from 'sonner';

const emptySubscribe = () => () => {};

/* ─── Main New Deal Form ─── */
export function NewDealForm() {
  const { setDashboardPanel, setActiveDeal, user } = useAppStore();
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);

  const [title, setTitle] = useState('');
  const [role, setRole] = useState('');
  const [partyEmail, setPartyEmail] = useState('');
  const [amount, setAmount] = useState('');
  const [terms, setTerms] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = useCallback(async () => {
    setError('');
    if (!title.trim() || !role || !partyEmail.trim() || !amount.trim()) {
      setError('সকল প্রয়োজনীয় ফিল্ড পূরণ করুন');
      return;
    }
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError('সঠিক পরিমাণ দিন (শূন্যের বেশি)');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/deals/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title.trim(),
          role,
          amount: numAmount,
          partyEmail: partyEmail.trim(),
          terms: terms.trim(),
          userId: user?.id,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'ডিল তৈরি ব্যর্থ হয়েছে');
        return;
      }
      const dealId = 'DL-' + (data.dealNumber || Math.floor(1000 + Math.random() * 9000));
      setActiveDeal({
        id: dealId,
        title: data.title || title.trim(),
        category: role === 'buyer' ? 'ক্রেতা' : 'বিক্রেতা',
        amount: numAmount,
        feePayer: role === 'buyer' ? 'ক্রেতা' : 'বিক্রেতা',
        status: 'created',
        createdAt: data.createdAt || new Date().toISOString(),
      });
      toast.success('ডিলটি সফলভাবে তৈরি হয়েছে!');
      setDashboardPanel('deal-detail');
    } catch {
      setError('সার্ভারে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  }, [title, role, partyEmail, amount, terms, user, setDashboardPanel, setActiveDeal]);

  if (!mounted) return null;

  const inputClass =
    'h-11 rounded-xl border-border bg-white dark:bg-zinc-800 dark:border-zinc-700 dark:placeholder:text-zinc-500 text-center md:text-left';

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="mx-auto w-full max-w-xl"
    >
      {/* ── Solid White Card ── */}
      <div className="rounded-2xl bg-white p-6 shadow-lg dark:bg-zinc-900 sm:p-8">
        {/* Header */}
        <div className="mb-7 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15">
            <PlusCircle className="h-6 w-6 text-primary" />
          </div>
          <h2 className="text-xl font-bold tracking-tight text-foreground">
            নতুন ডিল তৈরি করুন
          </h2>
          <p className="mt-1.5 text-sm text-muted-foreground">
            নিরাপদে লেনদেন সম্পন্ন করতে ডিলের তথ্য দিন
          </p>
        </div>

        {/* Form Fields */}
        <div className="space-y-5">
          {/* Field 1: ডিলের শিরোনাম */}
          <div className="space-y-2 text-center md:text-left">
            <Label htmlFor="deal-title" className="text-foreground text-sm">
              ডিলের শিরোনাম
            </Label>
            <Input
              id="deal-title"
              type="text"
              placeholder="যেমন: আইফোন ১৫ কেনাবেচা"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className={inputClass}
            />
          </div>

          {/* Field 2: আপনার ভূমিকা (Radio Buttons) */}
          <div className="space-y-3 text-center md:text-left">
            <Label className="text-foreground text-sm">
              আপনার ভূমিকা
            </Label>
            <div className="flex flex-col items-center gap-3 sm:flex-row sm:justify-start">
              {[
                { value: 'buyer', label: 'ক্রেতা (Buyer)', desc: 'আপনি টাকা পরিশোধ করবেন' },
                { value: 'seller', label: 'বিক্রেতা (Seller)', desc: 'আপনি পণ্য/সেবা দেবেন' },
              ].map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setRole(opt.value)}
                  className={`flex w-full sm:flex-1 items-center gap-3 rounded-xl border-2 p-4 text-left transition-all ${
                    role === opt.value
                      ? 'border-primary bg-primary/5 dark:bg-primary/10'
                      : 'border-border bg-white hover:border-primary/40 dark:bg-zinc-800 dark:hover:border-primary/40'
                  }`}
                >
                  <div
                    className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                      role === opt.value
                        ? 'border-primary bg-primary'
                        : 'border-muted-foreground/40'
                    }`}
                  >
                    {role === opt.value && (
                      <div className="h-2 w-2 rounded-full bg-white" />
                    )}
                  </div>
                  <div>
                    <p
                      className={`text-sm font-semibold ${
                        role === opt.value ? 'text-primary' : 'text-foreground'
                      }`}
                    >
                      {opt.label}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {opt.desc}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Field 3: প্রতিপক্ষের ইমেইল */}
          <div className="space-y-2 text-center md:text-left">
            <Label htmlFor="party-email" className="text-foreground text-sm">
              প্রতিপক্ষের ইমেইল
            </Label>
            <Input
              id="party-email"
              type="email"
              placeholder="opponent@example.com"
              value={partyEmail}
              onChange={(e) => setPartyEmail(e.target.value)}
              className={inputClass}
            />
          </div>

          {/* Field 4: ডিলের পরিমাণ (টাকা) */}
          <div className="space-y-2 text-center md:text-left">
            <Label htmlFor="deal-amount" className="text-foreground text-sm">
              ডিলের পরিমাণ (টাকা)
            </Label>
            <Input
              id="deal-amount"
              type="number"
              placeholder="যেমন: 50000"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className={inputClass}
            />
          </div>

          {/* Field 5: ডিলের শর্তাবলী */}
          <div className="space-y-2 text-center md:text-left">
            <Label htmlFor="deal-terms" className="text-foreground text-sm">
              ডিলের শর্তাবলী
            </Label>
            <Textarea
              id="deal-terms"
              placeholder="ডিলের বিস্তারিত শর্তাবলী লিখুন..."
              value={terms}
              onChange={(e) => setTerms(e.target.value)}
              rows={4}
              className="rounded-xl border-border bg-white dark:bg-zinc-800 dark:border-zinc-700 dark:placeholder:text-zinc-500 text-center md:text-left resize-none"
            />
          </div>
        </div>

        {/* Error */}
        <AnimatePresence>
          {error && (
            <motion.p
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              className="mt-5 text-center text-sm text-destructive"
            >
              {error}
            </motion.p>
          )}
        </AnimatePresence>

        {/* Submit Button */}
        <div className="mt-7">
          <Button
            onClick={handleSubmit}
            disabled={loading}
            className="w-full h-12 rounded-xl text-base font-semibold shadow-lg shadow-primary/25 dark:glow-lime gap-2.5"
          >
            {loading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <FileText className="h-5 w-5" />
            )}
            ডিল তৈরি করুন
          </Button>
        </div>
      </div>
    </motion.div>
  );
}