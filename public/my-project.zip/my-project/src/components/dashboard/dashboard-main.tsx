'use client';

import { useSyncExternalStore } from 'react';
import { motion } from 'framer-motion';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Bell,
  Menu,
  Plus,
  Wallet,
  TrendingUp,
  Handshake,
  ArrowUpRight,
} from 'lucide-react';
import { NewDealForm } from './new-deal-form';
import { DealWorkflowTracker } from './deal-workflow-tracker';
import { UserPaymentView } from './user-payment-view';

const emptySubscribe = () => () => {};

/* ─── Mock data ─── */
const stats = [
  {
    label: 'চলতি ডিল',
    value: '৪',
    icon: Handshake,
    color: 'text-primary',
    bg: 'bg-primary/10',
  },
  {
    label: 'সফল ডিল',
    value: '১২',
    icon: TrendingUp,
    color: 'text-emerald-500 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
  },
  {
    label: 'মোট লেনদেন (৳)',
    value: '১,৫০,০০০',
    icon: Wallet,
    color: 'text-amber-500 dark:text-amber-400',
    bg: 'bg-amber-500/10',
  },
];

const recentDeals = [
  {
    id: 'DL-১০২৪',
    title: 'আইফোন ১৫ প্রো ম্যাক্স',
    amount: '৳১,২০,০০০',
    status: 'চলমান',
  },
  {
    id: 'DL-১০১৮',
    title: 'ওয়ার্কপ্রেশন ডেস্কটপ',
    amount: '৳৮৫,০০০',
    status: 'টাকা জমা',
  },
  {
    id: 'DL-১০১২',
    title: 'সাইকেল - ফোর্স রেডি',
    amount: '৳১৫,০০০',
    status: 'সম্পন্ন',
  },
  {
    id: 'DL-১০০৫',
    title: 'গেমিং মনিটর ২৭" 165Hz',
    amount: '৳৪২,০০০',
    status: 'সম্পন্ন',
  },
  {
    id: 'DL-১০০১',
    title: 'হেডফোন - সনি WH-1000XM5',
    amount: '৳৩৫,৫০০',
    status: 'সম্পন্ন',
  },
];

function statusBadge(status: string) {
  switch (status) {
    case 'টাকা জমা':
      return (
        <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400 border-0 font-medium">
          {status}
        </Badge>
      );
    case 'চলমান':
      return (
        <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-400 border-0 font-medium">
          {status}
        </Badge>
      );
    case 'সম্পন্ন':
      return (
        <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400 border-0 font-medium">
          {status}
        </Badge>
      );
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

/* ─── Glass Card helper ─── */
function GlassCard({
  children,
  className = '',
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`relative rounded-2xl border !border-white/60 !bg-white/40 p-5 shadow-xl !backdrop-blur-xl dark:!border-zinc-800/50 dark:!bg-zinc-900/50 dark:!backdrop-blur-xl ${className}`}
    >
      {children}
    </div>
  );
}

/* ─── Overview Panel (original dashboard) ─── */
function OverviewPanel() {
  const user = useAppStore((s) => s.user);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);
  const setDashboardPanel = useAppStore((s) => s.setDashboardPanel);

  return (
    <>
      {/* ── Top Bar ── */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Mobile Menu Button */}
          <button
            onClick={() => setSidebarOpen(true)}
            className="flex h-10 w-10 items-center justify-center rounded-xl text-muted-foreground hover:bg-accent hover:text-foreground transition-colors lg:hidden"
            aria-label="মেনু"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="text-center lg:text-left">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
              স্বাগতম, {user?.name?.split(' ')[0] || 'ইউজার'}
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              আজকের ডিল ও লেনদেনের সারসংক্ষেপ
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Notification Bell */}
          <button
            className="relative flex h-10 w-10 items-center justify-center rounded-xl text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
            aria-label="নোটিফিকেশন"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-primary" />
          </button>
          {/* Profile Avatar */}
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-sm font-bold text-primary">
            {user?.name?.charAt(0) || 'ই'}
          </div>
        </div>
      </div>

      {/* ── Stats Grid ── */}
      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
            >
              <GlassCard>
                <div className="flex items-center justify-between text-center sm:text-left">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="mt-1 text-2xl font-bold tracking-tight text-foreground">
                      {stat.value}
                    </p>
                  </div>
                  <div
                    className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${stat.bg}`}
                  >
                    <Icon className={`h-5 w-5 ${stat.color}`} />
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          );
        })}
      </div>

      {/* ── Activity Grid: Quick Actions (top on mobile) + Deals Table (bottom on mobile) ── */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        {/* Right Column → Quick Actions (order-1 mobile, order-2 desktop) */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.25 }}
          className="order-1 lg:order-2 lg:col-span-2"
        >
          <GlassCard className="flex flex-col items-center gap-5 text-center">
            {/* CTA Button */}
            <div className="w-full">
              <h3 className="mb-4 text-base font-semibold text-foreground flex items-center justify-center gap-2">
                <ArrowUpRight className="h-4 w-4 text-primary" />
                কুইক অ্যাকশন
              </h3>
              <Button
                onClick={() => setDashboardPanel('new-deal')}
                className="w-full h-12 rounded-xl text-base font-semibold shadow-lg shadow-primary/25 dark:glow-lime gap-2.5"
              >
                <Plus className="h-5 w-5" />
                নতুন ডিল তৈরি করুন
              </Button>
            </div>

            {/* Divider */}
            <div className="w-full border-t border-border/50" />

            {/* Balance Summary */}
            <div className="w-full">
              <h3 className="mb-3 text-sm font-medium text-muted-foreground">
                অ্যাকাউন্ট সারসংক্ষেপ
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">উপলব্ধ ব্যালেন্স</span>
                  <span className="text-base font-bold text-foreground">৳২৫,৫০০.০০</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">হোল্ড থাকা টাকা</span>
                  <span className="text-base font-bold text-amber-500">৳১,২০,০০০.০০</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">মোট ব্যালেন্স</span>
                  <span className="text-base font-bold text-foreground">৳১,৪৫,৫০০.০০</span>
                </div>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Left Column → Recent Deals Table (order-2 mobile, order-1 desktop) */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.15 }}
          className="order-2 lg:order-1 lg:col-span-3"
        >
          <GlassCard className="!p-0 overflow-hidden">
            <div className="p-5 pb-3 text-center lg:text-left">
              <h3 className="text-base font-semibold text-foreground">
                সাম্প্রতিক ডিলসমূহ
              </h3>
              <p className="mt-1 text-xs text-muted-foreground">
                সাম্প্রতিক সকল ডিলের তালিকা
              </p>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-t border-b border-border/50 bg-muted/30">
                    <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                      ডিল আইডি
                    </th>
                    <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                      শিরোনাম
                    </th>
                    <th className="px-5 py-3 text-right text-xs font-semibold text-muted-foreground whitespace-nowrap">
                      পরিমাণ
                    </th>
                    <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                      অবস্থা
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {recentDeals.map((deal) => (
                    <tr
                      key={deal.id}
                      className="border-b border-border/30 transition-colors hover:bg-accent/30 last:border-0"
                    >
                      <td className="px-5 py-3.5 font-mono text-xs text-muted-foreground whitespace-nowrap">
                        {deal.id}
                      </td>
                      <td className="px-5 py-3.5 font-medium text-foreground max-w-[180px] truncate">
                        {deal.title}
                      </td>
                      <td className="px-5 py-3.5 text-right font-semibold text-foreground whitespace-nowrap">
                        {deal.amount}
                      </td>
                      <td className="px-5 py-3.5 text-center whitespace-nowrap">
                        {statusBadge(deal.status)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </GlassCard>
        </motion.div>
      </div>
    </>
  );
}

/* ─── Main Content ─── */
export function DashboardMain() {
  const dashboardPanel = useAppStore((s) => s.dashboardPanel);
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);

  if (!mounted) return null;

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8">
      {dashboardPanel === 'overview' && <OverviewPanel />}
      {dashboardPanel === 'new-deal' && <NewDealForm />}
      {dashboardPanel === 'deal-detail' && <DealWorkflowTracker />}
      {dashboardPanel === 'payment' && <UserPaymentView />}
    </div>
  );
}