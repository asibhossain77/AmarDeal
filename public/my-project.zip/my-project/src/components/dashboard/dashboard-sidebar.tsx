'use client';

import { useSyncExternalStore } from 'react';
import { useAppStore } from '@/lib/store';
import {
  LayoutDashboard,
  Handshake,
  ArrowLeftRight,
  UserCircle,
  LogOut,
  X,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const emptySubscribe = () => () => {};

interface NavItem {
  label: string;
  icon: React.ElementType;
  view: AppView;
}

const navItems: NavItem[] = [
  { label: 'ড্যাশবোর্ড', icon: LayoutDashboard, view: 'dashboard' },
  { label: 'আমার ডিল', icon: Handshake, view: 'dashboard' },
  { label: 'লেনদেন', icon: ArrowLeftRight, view: 'dashboard' },
  { label: 'প্রোফাইল', icon: UserCircle, view: 'dashboard' },
];

export function DashboardSidebar() {
  const { sidebarOpen, setSidebarOpen, logout, setDashboardPanel, setView, activeDeal } = useAppStore();
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);
  const user = useAppStore((s) => s.user);

  if (!mounted) return null;

  const handleLogout = () => {
    logout();
    setSidebarOpen(false);
  };

  const sidebarContent = (
    <div className="flex h-full flex-col">
      {/* Brand Header */}
      <div className="flex items-center justify-between p-5 pb-6">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary shadow-md shadow-primary/20">
            <span className="text-base font-bold leading-none text-primary-foreground">আ</span>
          </div>
          <span className="text-lg font-bold tracking-tight text-foreground">আমার ডিল</span>
        </div>
        <button
          onClick={() => setSidebarOpen(false)}
          className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground transition-colors lg:hidden"
          aria-label="বন্ধ করুন"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = item.label === 'ড্যাশবোর্ড';
          return (
            <button
              key={item.label}
              onClick={() => {
                if (item.label === 'ড্যাশবোর্ড') {
                  setDashboardPanel('overview');
                  setSidebarOpen(false);
                } else if (item.label === 'আমার ডিল' && activeDeal) {
                  setDashboardPanel('deal-detail');
                  setSidebarOpen(false);
                }
              }}
              className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-all ${
                isActive
                  ? 'bg-primary/10 text-primary dark:bg-primary/15'
                  : 'text-muted-foreground hover:bg-accent hover:text-foreground'
              }`}
            >
              <Icon className="h-[18px] w-[18px]" />
              {item.label}
            </button>
          );
        })}

      </nav>

      {/* User Info + Logout at bottom */}
      <div className="border-t border-border/50 p-4">
        <div className="flex items-center gap-3 rounded-xl px-3 py-2 mb-2">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/15 text-sm font-bold text-primary">
            {user?.name?.charAt(0) || 'ই'}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-foreground">{user?.name || 'ইউজার'}</p>
            <p className="truncate text-xs text-muted-foreground">{user?.email || ''}</p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-muted-foreground transition-all hover:bg-destructive/10 hover:text-destructive"
        >
          <LogOut className="h-[18px] w-[18px]" />
          লগআউট
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 lg:top-16 border-r border-border/50 bg-white dark:bg-zinc-900 z-40">
        {sidebarContent}
      </aside>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="fixed inset-y-0 left-0 z-50 w-72 border-r border-border/50 bg-white dark:bg-zinc-900 lg:hidden"
            >
              {sidebarContent}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}