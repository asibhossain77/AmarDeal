'use client';

import { useState, useRef, useEffect, useSyncExternalStore } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  ArrowLeft,
  FileCheck,
  Send,
  ShieldCheck,
  Truck,
  ThumbsUp,
  Check,
  Clock,
  Banknote,
  User,
  CalendarDays,
  ScrollText,
  SendHorizonal,
  Shield,
} from 'lucide-react';

const emptySubscribe = () => () => {};

/* ═══════════════════════════════════════════════════════════
   Types & Constants
   ═══════════════════════════════════════════════════════════ */

/** 5-step escrow progress — matches the reference image */
const STEPS = [
  { num: '১', label: 'ডিল তৈরি', icon: FileCheck },
  { num: '২', label: 'পেমেন্ট', icon: Send },
  { num: '৩', label: 'ভেরিফিকেশন', icon: ShieldCheck },
  { num: '৪', label: 'ডেলিভারি', icon: Truck },
  { num: '৫', label: 'সম্পন্ন', icon: ThumbsUp },
];

/** Demo step index — 3 means "ভেরিফিকেশন" is active */
const ACTIVE_STEP = 3;

/** Chat message roles */
type MessageRole = 'buyer' | 'seller' | 'admin';

interface ChatMessage {
  id: string;
  role: MessageRole;
  senderName: string;
  text: string;
  timestamp: string;
}

/** Seed chat messages for demo purposes */
const SEED_MESSAGES: ChatMessage[] = [
  {
    id: 'm1',
    role: 'buyer',
    senderName: 'রাকিব হাসান',
    text: 'ভাই, আইফোনটা কখন পাঠাবেন?',
    timestamp: '১০:৩০',
  },
  {
    id: 'm2',
    role: 'seller',
    senderName: 'টেক শপ',
    text: 'পেমেন্ট ভেরিফাই হলেই আজই পাঠিয়ে দিচ্ছি ইনশাআল্লাহ।',
    timestamp: '১০:৩২',
  },
  {
    id: 'm3',
    role: 'admin',
    senderName: 'আমার ডিল',
    text: 'পেমেন্ট ভেরিফিকেশন চলছে। অনুগ্রহ করে অপেক্ষা করুন।',
    timestamp: '১০:৩৫',
  },
  {
    id: 'm4',
    role: 'buyer',
    senderName: 'রাকিব হাসান',
    text: 'ওকে ভাই, পেমেন্ট করেছি। দেখুন প্লিজ।',
    timestamp: '১০:৩৬',
  },
  {
    id: 'm5',
    role: 'seller',
    senderName: 'টেক শপ',
    text: 'জায় আল্লাহ, দেখছি ভাই।',
    timestamp: '১০:৩৮',
  },
  {
    id: 'm6',
    role: 'admin',
    senderName: 'আমার ডিল',
    text: 'পেমেন্ট সফলভাবে ভেরিফাই হয়েছে। বিক্রেতাকে পণ্য পাঠানোর অনুরোধ করা হচ্ছে।',
    timestamp: '১০:৪০',
  },
];

/* ═══════════════════════════════════════════════════════════
   Sub-Components
   ═══════════════════════════════════════════════════════════ */

/**
 * Horizontal 5-step progress bar (desktop).
 * Active/completed steps use parrot green (#A3E635).
 */
function HorizontalStepper() {
  return (
    <div className="relative flex items-start justify-between">
      {/* Background track line */}
      <div className="absolute top-[18px] left-[18px] right-[18px] h-[3px] rounded-full bg-border/60" />
      {/* Filled progress line — extends to active step */}
      <div
        className="absolute top-[18px] left-[18px] h-[3px] rounded-full transition-all duration-700"
        style={{
          width: `calc(${(ACTIVE_STEP / (STEPS.length - 1)) * 100}% - 18px)`,
          backgroundColor: '#A3E635',
        }}
      />

      {STEPS.map((step, i) => {
        const Icon = step.icon;
        const isCompleted = i < ACTIVE_STEP;
        const isActive = i === ACTIVE_STEP;

        return (
          <div
            key={step.num}
            className="relative z-10 flex flex-col items-center"
            style={{ width: `${100 / STEPS.length}%` }}
          >
            {/* Step circle */}
            <div className="relative">
              {/* Pulse rings for active step */}
              {isActive && (
                <>
                  <span className="absolute -inset-2.5 rounded-full border-2 border-[#A3E635] animate-ping opacity-30" />
                  <span className="absolute -inset-1.5 rounded-full border-2 border-[#A3E635]/40 animate-pulse" />
                </>
              )}
              <div
                className="relative flex h-9 w-9 items-center justify-center rounded-full border-[3px] transition-all duration-300"
                style={{
                  backgroundColor: isCompleted || isActive ? '#A3E635' : 'var(--background)',
                  borderColor: isCompleted || isActive ? '#A3E635' : 'var(--border)',
                  color: isCompleted ? '#18181b' : isActive ? '#18181b' : 'var(--muted-foreground)',
                  boxShadow: isCompleted || isActive ? '0 4px 14px rgba(163,230,53,0.35)' : 'none',
                }}
              >
                {isCompleted ? (
                  <Check className="h-4 w-4" strokeWidth={3} />
                ) : (
                  <Icon className="h-4 w-4" />
                )}
              </div>
            </div>
            {/* Step label */}
            <p
              className="mt-2.5 text-center text-[11px] font-semibold leading-tight"
              style={{ color: isCompleted || isActive ? 'var(--foreground)' : 'var(--muted-foreground)' }}
            >
              {step.label}
            </p>
          </div>
        );
      })}
    </div>
  );
}

/**
 * Vertical 5-step stepper (mobile).
 * Stacks vertically with a connecting line.
 */
function VerticalStepper() {
  return (
    <div className="space-y-0">
      {STEPS.map((step, i) => {
        const Icon = step.icon;
        const isCompleted = i < ACTIVE_STEP;
        const isActive = i === ACTIVE_STEP;
        const isLast = i === STEPS.length - 1;

        return (
          <div key={step.num} className="flex gap-4">
            {/* Left column: circle + vertical connector */}
            <div className="flex flex-col items-center">
              <div className="relative">
                {isActive && (
                  <span className="absolute -inset-2 rounded-full border-2 border-[#A3E635]/40 animate-pulse" />
                )}
                <div
                  className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-[3px] transition-all duration-300"
                  style={{
                    backgroundColor: isCompleted || isActive ? '#A3E635' : 'var(--background)',
                    borderColor: isCompleted || isActive ? '#A3E635' : 'var(--border)',
                    color: isCompleted || isActive ? '#18181b' : 'var(--muted-foreground)',
                    boxShadow: isCompleted || isActive ? '0 4px 14px rgba(163,230,53,0.35)' : 'none',
                  }}
                >
                  {isCompleted ? (
                    <Check className="h-4 w-4" strokeWidth={3} />
                  ) : (
                    <Icon className="h-4 w-4" />
                  )}
                </div>
              </div>
              {/* Vertical connector line */}
              {!isLast && (
                <div className="w-[3px] flex-1 min-h-8 my-1.5 rounded-full">
                  <div
                    className="h-full w-full rounded-full transition-colors"
                    style={{ backgroundColor: isCompleted ? '#A3E635' : 'var(--border)' }}
                  />
                </div>
              )}
            </div>

            {/* Right column: step label */}
            <div className={`flex flex-col justify-center ${isLast ? '' : 'pb-4'}`}>
              <p
                className="text-sm font-semibold leading-tight"
                style={{ color: isCompleted || isActive ? 'var(--foreground)' : 'var(--muted-foreground)' }}
              >
                {step.label}
              </p>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                  ধাপ {step.num}
                </span>
                {isCompleted && (
                  <span className="text-xs font-medium" style={{ color: '#A3E635' }}>সম্পন্ন</span>
                )}
                {isActive && (
                  <span className="flex items-center gap-1 text-xs font-medium text-amber-500 dark:text-amber-400">
                    <span className="relative flex h-1.5 w-1.5">
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-400 opacity-75" />
                      <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-amber-500" />
                    </span>
                    অপেক্ষমান
                  </span>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/**
 * Detail info card used in the 2×2 grid.
 * Displays an icon, label, and value.
 */
function DetailCard({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-3 rounded-xl bg-muted/40 p-3.5">
      <div
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
        style={{ backgroundColor: '#A3E63520', color: '#A3E635' }}
      >
        <Icon className="h-5 w-5" />
      </div>
      <div className="min-w-0">
        <p className="text-xs font-medium" style={{ color: 'var(--muted-foreground)' }}>
          {label}
        </p>
        <p className="text-sm font-bold truncate" style={{ color: 'var(--foreground)' }}>
          {value}
        </p>
      </div>
    </div>
  );
}

/**
 * Single chat message bubble.
 *
 * Alignment logic:
 *  - buyer  → right-aligned, parrot green background
 *  - seller → left-aligned, light gray/neutral background
 *  - admin  → center-aligned, muted badge with border
 */
function ChatBubble({ message }: { message: ChatMessage }) {
  const { role, senderName, text, timestamp } = message;

  /* ── Admin messages: centered, muted badge ── */
  if (role === 'admin') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-center"
      >
        <div className="flex flex-col items-center gap-1 px-4 py-1">
          <div
            className="inline-flex items-center gap-2 rounded-lg border px-3.5 py-2 max-w-[85%] text-center"
            style={{
              backgroundColor: 'var(--muted)',
              borderColor: 'var(--border)',
            }}
          >
            <Shield className="h-3.5 w-3.5 shrink-0" style={{ color: 'var(--muted-foreground)' }} />
            <div>
              <p className="text-[10px] font-semibold" style={{ color: 'var(--muted-foreground)' }}>
                {senderName}
              </p>
              <p className="text-xs" style={{ color: 'var(--foreground)' }}>
                {text}
              </p>
            </div>
          </div>
          <span className="text-[10px]" style={{ color: 'var(--muted-foreground)' }}>
            {timestamp}
          </span>
        </div>
      </motion.div>
    );
  }

  /* ── Buyer: right-aligned, parrot green bg ── */
  const isBuyer = role === 'buyer';

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex ${isBuyer ? 'justify-end' : 'justify-start'}`}
    >
      <div className={`flex flex-col gap-1 max-w-[80%] ${isBuyer ? 'items-end' : 'items-start'}`}>
        <span
          className="text-[10px] font-semibold px-1"
          style={{ color: isBuyer ? '#A3E635' : 'var(--muted-foreground)' }}
        >
          {senderName}
        </span>
        <div
          className="rounded-2xl px-4 py-2.5"
          style={{
            backgroundColor: isBuyer ? '#A3E635' : 'var(--muted)',
            color: isBuyer ? '#18181b' : 'var(--foreground)',
            borderBottomRightRadius: isBuyer ? '4px' : '16px',
            borderBottomLeftRadius: isBuyer ? '16px' : '4px',
          }}
        >
          <p className="text-sm leading-relaxed">{text}</p>
        </div>
        <span className="text-[10px] px-1" style={{ color: 'var(--muted-foreground)' }}>
          {timestamp}
        </span>
      </div>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════
   Main Exported Component
   ═══════════════════════════════════════════════════════════ */

export function DealWorkflowTracker() {
  const { setDashboardPanel, activeDeal, user } = useAppStore();
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);

  /* Chat state */
  const [messages, setMessages] = useState<ChatMessage[]>(SEED_MESSAGES);
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  /* Auto-scroll chat to bottom when messages change */
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!mounted) return null;

  /* Deal data (falls back to demo values when no activeDeal is set) */
  const dealAmount = activeDeal?.amount ?? 50000;
  const dealTitle = activeDeal?.title ?? 'আইফোন ১৫ প্রো ম্যাক্স';
  const dealDate = activeDeal?.createdAt
    ? new Date(activeDeal.createdAt).toLocaleDateString('bn-BD', { year: 'numeric', month: 'short', day: 'numeric' })
    : '২৫ জুন, ২০২৫';

  /** Send a new chat message */
  const handleSend = () => {
    const trimmed = chatInput.trim();
    if (!trimmed) return;
    const now = new Date();
    const time = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });
    setMessages((prev) => [
      ...prev,
      {
        id: `msg_${Date.now()}`,
        role: 'buyer' as MessageRole,
        senderName: user?.name || 'আপনি',
        text: trimmed,
        timestamp: time,
      },
    ]);
    setChatInput('');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="mx-auto w-full max-w-2xl"
    >
      {/* ═════════════════════════════════════════
          Solid Container Card
          ═════════════════════════════════════════ */}
      <div
        className="overflow-hidden rounded-xl border shadow-lg"
        style={{
          backgroundColor: 'var(--background, #fff)',
          borderColor: 'var(--border)',
        }}
      >
        {/* ── Header ── */}
        <div
          className="flex items-center justify-between border-b px-4 py-3 sm:px-5"
          style={{ borderColor: 'var(--border)' }}
        >
          {/* Left: Back + Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setDashboardPanel('overview')}
              className="flex h-8 w-8 items-center justify-center rounded-lg transition-colors hover:bg-accent"
              aria-label="ফিরে যান"
            >
              <ArrowLeft className="h-4 w-4" style={{ color: 'var(--foreground)' }} />
            </button>
            <div className="flex items-center gap-2">
              {/* Logo mark */}
              <div
                className="flex h-8 w-8 items-center justify-center rounded-lg shadow-md"
                style={{ backgroundColor: '#A3E635' }}
              >
                <span className="text-sm font-bold" style={{ color: '#18181b' }}>
                  আ
                </span>
              </div>
              <span className="text-base font-bold tracking-tight" style={{ color: 'var(--foreground)' }}>
                আমার ডিল
              </span>
            </div>
          </div>

          {/* Center: Nav links (hidden on very small screens) */}
          <nav className="hidden sm:flex items-center gap-1">
            <button
              onClick={() => setDashboardPanel('overview')}
              className="rounded-lg px-3 py-1.5 text-xs font-medium transition-colors hover:bg-accent"
              style={{ color: 'var(--muted-foreground)' }}
            >
              ড্যাশবোর্ড
            </button>
            <button
              onClick={() => setDashboardPanel('new-deal')}
              className="rounded-lg px-3 py-1.5 text-xs font-medium transition-colors hover:bg-accent"
              style={{ color: 'var(--muted-foreground)' }}
            >
              নতুন ডিল
            </button>
          </nav>

          {/* Right: Profile */}
          <div className="flex items-center gap-2">
            <span className="hidden sm:block text-xs font-medium truncate max-w-[100px]" style={{ color: 'var(--muted-foreground)' }}>
              {user?.name || 'ইউজার'}
            </span>
            <div
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold"
              style={{ backgroundColor: '#A3E63525', color: '#A3E635' }}
            >
              {user?.name?.charAt(0) || 'ই'}
            </div>
          </div>
        </div>

        {/* ── Tab System ── */}
        <Tabs defaultValue="deal-info" className="w-full">
          {/* Tab bar */}
          <div
            className="border-b px-4 sm:px-5"
            style={{ borderColor: 'var(--border)' }}
          >
            <TabsList className="w-full h-11 rounded-none bg-transparent p-0 gap-0">
              <TabsTrigger
                value="deal-info"
                className="relative flex-1 h-full rounded-none border-b-2 border-transparent text-sm font-semibold transition-all data-[state=active]:border-[#A3E635] data-[state=active]:bg-transparent data-[state=active]:text-foreground data-[state=active]:shadow-none px-0"
                style={{ color: 'var(--muted-foreground)' }}
              >
                ডিলের তথ্য
              </TabsTrigger>
              <TabsTrigger
                value="deal-chat"
                className="relative flex-1 h-full rounded-none border-b-2 border-transparent text-sm font-semibold transition-all data-[state=active]:border-[#A3E635] data-[state=active]:bg-transparent data-[state=active]:text-foreground data-[state=active]:shadow-none px-0"
                style={{ color: 'var(--muted-foreground)' }}
              >
                ডিল চ্যাট
                {/* Unread dot indicator */}
                <span className="absolute top-2.5 right-4 h-2 w-2 rounded-full bg-[#A3E635]" />
              </TabsTrigger>
            </TabsList>
          </div>

          {/* ═══════════════════════════════════
              TAB 1: ডিলের তথ্য (Deal Info)
              ═══════════════════════════════════ */}
          <TabsContent value="deal-info" className="mt-0">
            <div className="p-4 sm:p-6 space-y-6">
              {/* ── Deal title + status ── */}
              <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-lg font-bold" style={{ color: 'var(--foreground)' }}>
                    {dealTitle}
                  </h2>
                  <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
                    DL-{(activeDeal?.id || '1025').slice(-5)}
                  </p>
                </div>
                <Badge
                  className="w-fit border-0 font-medium text-xs"
                  style={{ backgroundColor: '#A3E63525', color: '#A3E635' }}
                >
                  প্রক্রিয়াধীন
                </Badge>
              </div>

              {/* ── 5-Step Progress Bar ── */}
              <div className="py-2">
                {/* Desktop: horizontal */}
                <div className="hidden md:block">
                  <HorizontalStepper />
                </div>
                {/* Mobile: vertical */}
                <div className="md:hidden">
                  <VerticalStepper />
                </div>
              </div>

              {/* ── Details Grid (2×2 desktop, stacked mobile) ── */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <DetailCard
                  icon={Banknote}
                  label="ডিলের পরিমাণ"
                  value={`৳${dealAmount.toLocaleString('bn-BD')}`}
                />
                <DetailCard
                  icon={User}
                  label="ক্রেতা"
                  value={user?.name || 'রাকিব হাসান'}
                />
                <DetailCard
                  icon={User}
                  label="বিক্রেতা"
                  value="টেক শপ"
                />
                <DetailCard
                  icon={CalendarDays}
                  label="তৈরির তারিখ"
                  value={dealDate}
                />
              </div>

              {/* ── Terms Section ── */}
              <div
                className="rounded-xl border p-4"
                style={{ borderColor: 'var(--border)', backgroundColor: 'var(--muted)' }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <ScrollText className="h-4 w-4" style={{ color: '#A3E635' }} />
                  <h3 className="text-sm font-semibold" style={{ color: 'var(--foreground)' }}>
                    ডিলের শর্তাবলী
                  </h3>
                </div>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
                  ১. ক্রেতা পেমেন্ট সম্পন্ন করলে বিক্রেতা পণ্য পাঠাবে।
                  ২. ক্রেতা পণ্য পেয়ে যাচাই করলে টাকা বিক্রেতার কাছে যাবে।
                  ৩. কোনো বিবাদ হলে অ্যাডমিন হস্তক্ষেপ করবে।
                  ৪. পণ্যের কোনো ক্ষতি হলে এসক্রো টাকা ফেরত দেওয়া হবে।
                </p>
              </div>

              {/* ── Primary Action: Payment Button ── */}
              <Button
                onClick={() => setDashboardPanel('payment')}
                className="w-full h-12 rounded-xl text-base font-bold gap-2.5 transition-transform hover:scale-[1.01] active:scale-[0.99]"
                style={{
                  backgroundColor: '#A3E635',
                  color: '#18181b',
                  boxShadow: '0 6px 24px rgba(163,230,53,0.3)',
                }}
              >
                <ShieldCheck className="h-5 w-5" />
                পেমেন্ট করুন
              </Button>
            </div>
          </TabsContent>

          {/* ═══════════════════════════════════
              TAB 2: ডিল চ্যাট (Deal Chat)
              ═══════════════════════════════════ */}
          <TabsContent value="deal-chat" className="mt-0">
            <div className="flex flex-col" style={{ height: '420px' }}>
              {/* ── Scrollable message area ── */}
              <div
                className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4"
                style={{
                  backgroundColor: 'var(--muted)',
                  scrollbarWidth: 'thin',
                }}
              >
                <AnimatePresence initial={false}>
                  {messages.map((msg) => (
                    <ChatBubble key={msg.id} message={msg} />
                  ))}
                </AnimatePresence>
                <div ref={chatEndRef} />
              </div>

              {/* ── Fixed input box ── */}
              <div
                className="flex items-center gap-2 border-t p-3 sm:p-4"
                style={{ borderColor: 'var(--border)', backgroundColor: 'var(--background, #fff)' }}
              >
                <Input
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="মেসেজ লিখুন..."
                  className="flex-1 h-10 rounded-xl border text-sm"
                />
                <Button
                  onClick={handleSend}
                  disabled={!chatInput.trim()}
                  size="icon"
                  className="h-10 w-10 shrink-0 rounded-xl"
                  style={{
                    backgroundColor: chatInput.trim() ? '#A3E635' : undefined,
                    color: chatInput.trim() ? '#18181b' : undefined,
                  }}
                >
                  <SendHorizonal className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </motion.div>
  );
}