'use client';

import { useSyncExternalStore } from 'react';
import { motion } from 'framer-motion';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Bell,
  Menu,
  Inbox,
  Clock,
  TrendingUp,
  Plus,
  Truck,
  Pencil,
} from 'lucide-react';
import { toast } from 'sonner';

const emptySubscribe = () => () => {};

/* ═══════════════════════════════════════════
   Mock Data
   ═══════════════════════════════════════════ */

const sellerStats = [
  {
    label: 'ইনকামিং ডিল',
    value: '৩',
    icon: Inbox,
    color: 'text-primary',
    bg: 'bg-primary/10',
  },
  {
    label: 'চলমান ডিল',
    value: '২',
    icon: Clock,
    color: 'text-amber-500 dark:text-amber-400',
    bg: 'bg-amber-500/10',
  },
  {
    label: 'মোট আয় (৳)',
    value: '২,৮২,৫০০',
    icon: TrendingUp,
    color: 'text-emerald-500 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
  },
];

const recentIncomingDeals = [
  {
    id: 'DL-১০৩০',
    buyer: 'রাহুল আহমেদ',
    title: 'আইফোন ১৫ প্রো ম্যাক্স',
    amount: '৳১,২০,০০০',
    status: 'নতুন',
  },
  {
    id: 'DL-১০২৮',
    buyer: 'ফাতেমা খানম',
    title: 'ম্যাকবুক এয়ার M2',
    amount: '৳৯৫,০০০',
    status: 'পর্যালোচনাধীন',
  },
  {
    id: 'DL-১০২৫',
    buyer: 'তানভীর ইসলাম',
    title: 'এয়ারপডস প্রো ২',
    amount: '৳২৮,৫০০',
    status: 'নতুন',
  },
  {
    id: 'DL-১০২২',
    buyer: 'নুসরাত জাহান',
    title: 'অ্যাপল ওয়াচ আল্ট্রা',
    amount: '৳৩৮,০০০',
    status: 'গ্রহণ করা হয়েছে',
  },
];

const incomingDeals = [
  {
    id: 'DL-১০৩০',
    buyer: 'রাহুল আহমেদ',
    title: 'আইফোন ১৫ প্রো ম্যাক্স',
    amount: '৳১,২০,০০০',
    date: '২ ঘন্টা আগে',
  },
  {
    id: 'DL-১০২৮',
    buyer: 'ফাতেমা খানম',
    title: 'ম্যাকবুক এয়ার M2',
    amount: '৳৯৫,০০০',
    date: '৫ ঘন্টা আগে',
  },
  {
    id: 'DL-১০২৫',
    buyer: 'তানভীর ইসলাম',
    title: 'এয়ারপডস প্রো ২',
    amount: '৳২৮,৫০০',
    date: '১ দিন আগে',
  },
];

const activeDeals = [
  {
    id: 'DL-১০২২',
    title: 'অ্যাপল ওয়াচ আল্ট্রা',
    amount: '৳৩৮,০০০',
    status: 'পেমেন্ট যাচাইকৃত',
    action: false,
  },
  {
    id: 'DL-১০১৯',
    title: 'আইফোন ১৫',
    amount: '৳৮৫,০০০',
    status: 'ডেলিভারি প্রক্রিয়াধীন',
    action: true,
  },
];

const myProducts = [
  {
    name: 'আইফোন ১৫ প্রো ম্যাক্স',
    price: '৳১,২০,০০০',
    status: 'সক্রিয়' as const,
  },
  {
    name: 'ম্যাকবুক এয়ার M2',
    price: '৳৯৫,০০০',
    status: 'সক্রিয়' as const,
  },
  {
    name: 'এয়ারপডস প্রো ২',
    price: '৳২৮,৫০০',
    status: 'বিক্রিত' as const,
  },
  {
    name: 'অ্যাপল ওয়াচ আল্ট্রা',
    price: '৳৩৮,০০০',
    status: 'সক্রিয়' as const,
  },
];

/* ═══════════════════════════════════════════
   Helpers
   ═══════════════════════════════════════════ */

function SolidCard({
  children,
  className = '',
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`rounded-2xl bg-white p-5 shadow-lg dark:bg-zinc-900 ${className}`}>
      {children}
    </div>
  );
}

function statusBadge(status: string) {
  switch (status) {
    case 'নতুন':
      return (
        <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-400 border-0 font-medium">
          {status}
        </Badge>
      );
    case 'পর্যালোচনাধীন':
      return (
        <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400 border-0 font-medium">
          {status}
        </Badge>
      );
    case 'গ্রহণ করা হয়েছে':
    case 'পেমেন্ট যাচাইকৃত':
      return (
        <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400 border-0 font-medium">
          {status}
        </Badge>
      );
    case 'ডেলিভারি প্রক্রিয়াধীন':
      return (
        <Badge className="bg-primary/15 text-primary dark:bg-primary/20 border-0 font-medium">
          {status}
        </Badge>
      );
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

function productStatusBadge(status: 'সক্রিয়' | 'বিক্রিত') {
  if (status === 'সক্রিয়') {
    return (
      <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400 border-0 font-medium">
        সক্রিয়
      </Badge>
    );
  }
  return (
    <Badge className="bg-zinc-100 text-zinc-600 dark:bg-zinc-700/40 dark:text-zinc-400 border-0 font-medium">
      বিক্রিত
    </Badge>
  );
}

/* ═══════════════════════════════════════════
   Panel: Overview
   ═══════════════════════════════════════════ */

function SellerOverviewPanel() {
  const user = useAppStore((s) => s.user);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);

  return (
    <>
      {/* Top Bar */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSidebarOpen(true)}
            className="flex h-10 w-10 items-center justify-center rounded-xl text-muted-foreground hover:bg-accent hover:text-foreground transition-colors lg:hidden"
            aria-label="মেনু"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="text-center lg:text-left">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
              স্বাগতম, {user?.name?.split(' ')[0] || 'বিক্রেতা'}
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              আপনার বিক্রয় ড্যাশবোর্ডের সারসংক্ষেপ
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            className="relative flex h-10 w-10 items-center justify-center rounded-xl text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
            aria-label="নোটিফিকেশন"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-primary" />
          </button>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-sm font-bold text-primary">
            {user?.name?.charAt(0) || 'ব'}
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        {sellerStats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
            >
              <SolidCard>
                <div className="flex items-center justify-between text-center sm:text-left">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="mt-1 text-2xl font-bold tracking-tight text-foreground">
                      {stat.value}
                    </p>
                  </div>
                  <div
                    className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${stat.bg}`}
                  >
                    <Icon className={`h-5 w-5 ${stat.color}`} />
                  </div>
                </div>
              </SolidCard>
            </motion.div>
          );
        })}
      </div>

      {/* Content Grid: Deals Table + Quick Action */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        {/* Deals Table */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.15 }}
          className="order-2 lg:order-1 lg:col-span-3"
        >
          <SolidCard className="!p-0 overflow-hidden">
            <div className="p-5 pb-3 text-center lg:text-left">
              <h3 className="text-base font-semibold text-foreground">
                সাম্প্রতিক ইনকামিং ডিলসমূহ
              </h3>
              <p className="mt-1 text-xs text-muted-foreground">
                ক্রেতাদের কাছ থেকে আসা সাম্প্রতিক ডিল
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-t border-b border-border/50 bg-muted/30">
                    <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                      ডিল আইডি
                    </th>
                    <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                      ক্রেতা
                    </th>
                    <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                      শিরোনাম
                    </th>
                    <th className="px-5 py-3 text-right text-xs font-semibold text-muted-foreground whitespace-nowrap">
                      পরিমাণ
                    </th>
                    <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                      অবস্থা
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {recentIncomingDeals.map((deal) => (
                    <tr
                      key={deal.id}
                      className="border-b border-border/30 transition-colors hover:bg-accent/30 last:border-0"
                    >
                      <td className="px-5 py-3.5 font-mono text-xs text-muted-foreground whitespace-nowrap">
                        {deal.id}
                      </td>
                      <td className="px-5 py-3.5 text-foreground whitespace-nowrap">
                        {deal.buyer}
                      </td>
                      <td className="px-5 py-3.5 font-medium text-foreground max-w-[160px] truncate">
                        {deal.title}
                      </td>
                      <td className="px-5 py-3.5 text-right font-semibold text-foreground whitespace-nowrap">
                        {deal.amount}
                      </td>
                      <td className="px-5 py-3.5 text-center whitespace-nowrap">
                        {statusBadge(deal.status)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </SolidCard>
        </motion.div>

        {/* Quick Action */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.25 }}
          className="order-1 lg:order-2 lg:col-span-2"
        >
          <SolidCard className="flex flex-col items-center gap-5 text-center">
            <div className="w-full">
              <h3 className="mb-4 text-base font-semibold text-foreground">
                কুইক অ্যাকশন
              </h3>
              <Button
                onClick={() => toast.success('ডেলিভারি আপডেট পেজে নিচ্ছি...')}
                className="w-full h-12 rounded-xl text-base font-semibold shadow-lg shadow-primary/25 gap-2.5"
              >
                <Truck className="h-5 w-5" />
                ডেলিভারি আপডেট করুন
              </Button>
            </div>

            <div className="w-full border-t border-border/50" />

            <div className="w-full">
              <h3 className="mb-3 text-sm font-medium text-muted-foreground">
                এই সপ্তাহের সারসংক্ষেপ
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">নতুন অর্ডার</span>
                  <span className="text-base font-bold text-foreground">৩</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">ডেলিভারি সম্পন্ন</span>
                  <span className="text-base font-bold text-emerald-500">২</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">মোট আয়</span>
                  <span className="text-base font-bold text-foreground">৳২,৮২,৫০০</span>
                </div>
              </div>
            </div>
          </SolidCard>
        </motion.div>
      </div>
    </>
  );
}

/* ═══════════════════════════════════════════
   Panel: Incoming Deals
   ═══════════════════════════════════════════ */

function IncomingDealsPanel() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="text-center lg:text-left">
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
          ইনকামিং ডিলসমূহ
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          ক্রেতাদের কাছ থেকে আসা নতুন ডিলের অনুরোধ
        </p>
      </div>

      {/* Deal Cards */}
      <div className="space-y-4">
        {incomingDeals.map((deal, i) => (
          <motion.div
            key={deal.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: i * 0.08 }}
          >
            <SolidCard>
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 text-center sm:text-left">
                    <span className="font-mono text-xs text-muted-foreground">{deal.id}</span>
                    <span className="text-xs text-muted-foreground">{deal.date}</span>
                  </div>
                  <p className="text-base font-semibold text-foreground text-center sm:text-left">
                    {deal.title}
                  </p>
                  <div className="flex items-center gap-3 mt-1.5 justify-center sm:justify-start">
                    <span className="text-sm text-muted-foreground">ক্রেতা:</span>
                    <span className="text-sm font-medium text-foreground">{deal.buyer}</span>
                  </div>
                  <p className="text-lg font-bold text-primary mt-1.5 text-center sm:text-left">
                    {deal.amount}
                  </p>
                </div>
                <div className="flex items-center gap-3 sm:flex-col sm:items-end">
                  <Button
                    onClick={() => toast.success(`"${deal.title}" ডিলটি গ্রহণ করা হয়েছে`)}
                    className="flex-1 sm:flex-none rounded-xl text-sm font-semibold shadow-md shadow-primary/20 px-5"
                  >
                    গ্রহণ করুন
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => toast.error(`"${deal.title}" ডিলটি প্রত্যাখ্যান করা হয়েছে`)}
                    className="flex-1 sm:flex-none rounded-xl text-sm font-medium text-destructive hover:bg-destructive/10 hover:text-destructive border-destructive/30"
                  >
                    প্রত্যাখ্যান করুন
                  </Button>
                </div>
              </div>
            </SolidCard>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════
   Panel: Active Deals
   ═══════════════════════════════════════════ */

function ActiveDealsPanel() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="text-center lg:text-left">
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
          চলমান ডিলসমূহ
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          বর্তমানে চলমান সকল ডিলের তালিকা
        </p>
      </div>

      {/* Table */}
      <SolidCard className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border/50 bg-muted/30">
                <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                  ডিল আইডি
                </th>
                <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                  শিরোনাম
                </th>
                <th className="px-5 py-3 text-right text-xs font-semibold text-muted-foreground whitespace-nowrap">
                  পরিমাণ
                </th>
                <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                  স্ট্যাটাস
                </th>
                <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                  অ্যাকশন
                </th>
              </tr>
            </thead>
            <tbody>
              {activeDeals.map((deal) => (
                <tr
                  key={deal.id}
                  className="border-b border-border/30 transition-colors hover:bg-accent/30 last:border-0"
                >
                  <td className="px-5 py-3.5 font-mono text-xs text-muted-foreground whitespace-nowrap">
                    {deal.id}
                  </td>
                  <td className="px-5 py-3.5 font-medium text-foreground whitespace-nowrap">
                    {deal.title}
                  </td>
                  <td className="px-5 py-3.5 text-right font-semibold text-foreground whitespace-nowrap">
                    {deal.amount}
                  </td>
                  <td className="px-5 py-3.5 text-center whitespace-nowrap">
                    {statusBadge(deal.status)}
                  </td>
                  <td className="px-5 py-3.5 text-center whitespace-nowrap">
                    {deal.action ? (
                      <Button
                        size="sm"
                        onClick={() => toast.success(`"${deal.title}" ডেলিভারি কনফার্ম করা হয়েছে`)}
                        className="rounded-lg text-xs font-semibold shadow-md shadow-primary/20"
                      >
                        ডেলিভারি কনফার্ম করুন
                      </Button>
                    ) : (
                      <span className="text-xs text-muted-foreground">--</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </SolidCard>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════
   Panel: My Products
   ═══════════════════════════════════════════ */

function MyProductsPanel() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between text-center sm:text-left">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground">
            আমার পণ্যসমূহ
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            আপনার বিক্রয়যোগ্য পণ্যের তালিকা
          </p>
        </div>
        <Button
          onClick={() => toast.success('নতুন পণ্য যোগ করার পেজে নিচ্ছি...')}
          className="rounded-xl text-sm font-semibold shadow-lg shadow-primary/25 gap-2 sm:self-start"
        >
          <Plus className="h-4 w-4" />
          নতুন পণ্য যোগ করুন
        </Button>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {myProducts.map((product, i) => (
          <motion.div
            key={product.name}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: i * 0.08 }}
          >
            <SolidCard className="flex flex-col gap-3">
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <p className="text-base font-semibold text-foreground truncate">
                    {product.name}
                  </p>
                  <p className="text-lg font-bold text-primary mt-1">
                    {product.price}
                  </p>
                </div>
                {productStatusBadge(product.status)}
              </div>
              <div className="mt-auto pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => toast.info(`"${product.name}" সম্পাদনা পেজে নিচ্ছি...`)}
                  className="w-full rounded-lg text-sm font-medium gap-2"
                >
                  <Pencil className="h-3.5 w-3.5" />
                  সম্পাদনা
                </Button>
              </div>
            </SolidCard>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════
   Main Content Router
   ═══════════════════════════════════════════ */

export function SellerMain() {
  const sellerPanel = useAppStore((s) => s.sellerPanel);
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);

  if (!mounted) return null;

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8">
      {sellerPanel === 'overview' && <SellerOverviewPanel />}
      {sellerPanel === 'incoming-deals' && <IncomingDealsPanel />}
      {sellerPanel === 'active-deals' && <ActiveDealsPanel />}
      {sellerPanel === 'my-products' && <MyProductsPanel />}
    </div>
  );
}