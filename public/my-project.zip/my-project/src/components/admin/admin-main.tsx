'use client';

import { useState, useEffect, useSyncExternalStore, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useAppStore, type AdminPanel } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { PaymentMethodsPanel } from './payment-methods-panel';
import {
  Menu,
  Bell,
  ShieldCheck,
  ShieldX,
  Handshake,
  Wallet,
  Users,
  Settings,
  CheckCircle,
  Loader2,
  Search,
  ChevronDown,
  Save,
} from 'lucide-react';

const emptySubscribe = () => () => {};

/* ─── Types ─── */
interface DealRow {
  id: string;
  title: string;
  amount: number;
  status: string;
  createdAt: string;
  buyer?: { name: string; email: string } | null;
  seller?: { name: string; email: string } | null;
  creator?: { name: string; email: string } | null;
}

interface UserRow {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  createdAt: string;
}

interface AdminStats {
  totalDeals: number;
  pendingDeals: number;
  totalAmount: number;
}

interface PlatformSettings {
  platform_name: string;
  fee_percentage: string;
  min_deal_amount: string;
  max_deal_amount: string;
  support_number: string;
}

/* ─── Solid Card Helper ─── */
function SolidCard({
  children,
  className = '',
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`rounded-2xl bg-white p-5 shadow-lg dark:bg-zinc-900 ${className}`}
    >
      {children}
    </div>
  );
}

/* ─── Status Badge Helper ─── */
function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    created: {
      label: 'তৈরি',
      classes:
        'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400',
    },
    pending: {
      label: 'পেন্ডিং',
      classes:
        'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400',
    },
    payment_pending: {
      label: 'পেমেন্ট পেন্ডিং',
      classes:
        'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400',
    },
    payment_verified: {
      label: 'ভেরিফাইড',
      classes:
        'bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-400',
    },
    in_delivery: {
      label: 'ডেলিভারি',
      classes:
        'bg-primary/15 text-primary dark:bg-primary/20',
    },
    delivery_confirmed: {
      label: 'ডেলিভারি কনফার্মড',
      classes:
        'bg-primary/15 text-primary dark:bg-primary/20',
    },
    completed: {
      label: 'সম্পন্ন',
      classes:
        'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400',
    },
    rejected: {
      label: 'রিজেক্টেড',
      classes:
        'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400',
    },
  };
  const c =
    config[status] || {
      label: status,
      classes:
        'bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-400',
    };
  return (
    <Badge className={`${c.classes} border-0 font-medium`}>{c.label}</Badge>
  );
}

/* ─── Role Badge Helper ─── */
function RoleBadge({ role }: { role: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    user: {
      label: 'ইউজার',
      classes:
        'bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-400',
    },
    seller: {
      label: 'বিক্রেতা',
      classes: 'bg-primary/15 text-primary dark:bg-primary/15 dark:text-primary',
    },
    admin: {
      label: 'অ্যাডমিন',
      classes:
        'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400',
    },
  };
  const c = config[role] || config.user;
  return (
    <Badge className={`${c.classes} border-0 font-medium`}>{c.label}</Badge>
  );
}

/* ─── Loading Spinner ─── */
function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center py-16">
      <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
    </div>
  );
}

/* ═══════════════════════════════════════════
   Panel 1: ড্যাশবোর্ড — 3 Stats Cards
   ═══════════════════════════════════════════ */

function DashboardStatsPanel() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch('/api/admin/stats');
        if (res.ok) {
          const data = await res.json();
          setStats(data);
        }
      } catch {
        // silent
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  const cards = stats
    ? [
        {
          label: 'মোট ডিল',
          value: stats.totalDeals.toLocaleString('bn-BD'),
          icon: Handshake,
          color: 'text-primary',
          bg: 'bg-primary/10',
        },
        {
          label: 'পেন্ডিং ভেরিফিকেশন',
          value: stats.pendingDeals.toLocaleString('bn-BD'),
          icon: ShieldCheck,
          color: 'text-amber-500 dark:text-amber-400',
          bg: 'bg-amber-500/10',
        },
        {
          label: 'মোট লেনদেন (৳)',
          value: Math.round(stats.totalAmount).toLocaleString('bn-BD'),
          icon: Wallet,
          color: 'text-emerald-500 dark:text-emerald-400',
          bg: 'bg-emerald-500/10',
        },
      ]
    : [];

  if (loading) return <LoadingSpinner />;

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
      {cards.map((stat, i) => {
        const Icon = stat.icon;
        return (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
          >
            <SolidCard>
              <div className="flex items-center justify-between text-center sm:text-left">
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="mt-1.5 text-2xl font-bold tracking-tight text-foreground">
                    {stat.value}
                  </p>
                </div>
                <div
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${stat.bg}`}
                >
                  <Icon className={`h-5 w-5 ${stat.color}`} />
                </div>
              </div>
            </SolidCard>
          </motion.div>
        );
      })}
    </div>
  );
}

/* ═══════════════════════════════════════════
   Panel 2: পেমেন্ট ভেরিফিকেশন (Core)
   ═══════════════════════════════════════════ */

function PaymentVerifyPanel() {
  const [deals, setDeals] = useState<DealRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const fetchDeals = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/deals');
      if (res.ok) {
        const data = await res.json();
        setDeals(data);
      }
    } catch {
      // use fallback
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDeals();
  }, [fetchDeals]);

  const handleVerify = async (dealId: string) => {
    setActionLoading(dealId);
    try {
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dealId }),
      });
      if (res.ok) {
        toast.success('পেমেন্ট সফলভাবে ভেরিফাই হয়েছে!');
        fetchDeals();
      } else {
        toast.error('ভেরিফিকেশন ব্যর্থ হয়েছে');
      }
    } catch {
      toast.error('সার্ভারে সমস্যা');
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (dealId: string) => {
    setActionLoading(dealId);
    try {
      const res = await fetch('/api/admin/reject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dealId }),
      });
      if (res.ok) {
        toast.success('ডিল রিজেক্ট করা হয়েছে');
        fetchDeals();
      } else {
        toast.error('রিজেক্ট ব্যর্থ হয়েছে');
      }
    } catch {
      toast.error('সার্ভারে সমস্যা');
    } finally {
      setActionLoading(null);
    }
  };

  const pendingDeals = deals.filter(
    (d) =>
      d.status === 'created' ||
      d.status === 'pending' ||
      d.status === 'payment_pending'
  );

  return (
    <div>
      {/* Section Header */}
      <div className="mb-5 flex flex-col items-center gap-3 sm:flex-row sm:justify-between">
        <div className="text-center sm:text-left">
          <h2 className="text-lg font-bold text-foreground flex items-center justify-center sm:justify-start gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            পেমেন্ট ভেরিফিকেশন
          </h2>
          <p className="mt-0.5 text-sm text-muted-foreground">
            ভেরিফিকেশনের অপেক্ষমান ডিলসমূহ পর্যালোচনা করুন
          </p>
        </div>
        <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400 border-0 text-xs font-medium">
          {pendingDeals.length} পেন্ডিং
        </Badge>
      </div>

      {/* Table Card */}
      <SolidCard className="!p-0 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : pendingDeals.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <CheckCircle className="mb-3 h-10 w-10 text-primary" />
            <p className="text-sm font-semibold text-foreground">
              সব পেমেন্ট ভেরিফাই হয়েছে
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              বর্তমানে কোনো পেন্ডিং ডিল নেই
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[640px]">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    ডিল আইডি
                  </th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    ইউজার নেম
                  </th>
                  <th className="px-5 py-3 text-right text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    পরিমাণ (৳)
                  </th>
                  <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    পেমেন্ট স্ট্যাটাস
                  </th>
                  <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    অ্যাকশন
                  </th>
                </tr>
              </thead>
              <tbody>
                {pendingDeals.map((deal) => {
                  const shortId =
                    deal.id.length > 10
                      ? 'DL-' + deal.id.slice(-5)
                      : deal.id;
                  const userName =
                    deal.creator?.name || deal.buyer?.name || 'ইউজার';
                  const isActing = actionLoading === deal.id;

                  return (
                    <tr
                      key={deal.id}
                      className="border-b border-border/30 transition-colors hover:bg-muted/20 last:border-0"
                    >
                      <td className="px-5 py-4 font-mono text-xs text-muted-foreground whitespace-nowrap">
                        {shortId}
                      </td>
                      <td className="px-5 py-4 font-medium text-foreground whitespace-nowrap">
                        {userName}
                      </td>
                      <td className="px-5 py-4 text-right font-semibold text-foreground whitespace-nowrap">
                        ৳{deal.amount.toLocaleString('bn-BD')}
                      </td>
                      <td className="px-5 py-4 text-center whitespace-nowrap">
                        <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400 border-0 font-medium">
                          পেন্ডিং
                        </Badge>
                      </td>
                      <td className="px-5 py-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            disabled={isActing}
                            onClick={() => handleVerify(deal.id)}
                            className="h-9 gap-1.5 rounded-lg text-xs font-semibold shadow-md shadow-primary/25"
                          >
                            {isActing ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <ShieldCheck className="h-3.5 w-3.5" />
                            )}
                            পেমেন্ট ভেরিফাই করুন
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={isActing}
                            onClick={() => handleReject(deal.id)}
                            className="h-9 gap-1.5 rounded-lg text-xs font-medium border-red-200 text-red-600 hover:bg-red-50 dark:border-red-800/50 dark:text-red-400 dark:hover:bg-red-500/10"
                          >
                            {isActing ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <ShieldX className="h-3.5 w-3.5" />
                            )}
                            রিজেক্ট করুন
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </SolidCard>
    </div>
  );
}

/* ═══════════════════════════════════════════
   Panel 3: সকল ডিল
   ═══════════════════════════════════════════ */

type DealFilter = 'all' | 'pending' | 'verified' | 'delivery' | 'completed';

const dealFilterTabs: {
  key: DealFilter;
  label: string;
  statuses: string[];
}[] = [
  { key: 'all', label: 'সকল', statuses: [] },
  {
    key: 'pending',
    label: 'পেন্ডিং',
    statuses: ['created', 'pending', 'payment_pending'],
  },
  { key: 'verified', label: 'ভেরিফাইড', statuses: ['payment_verified'] },
  {
    key: 'delivery',
    label: 'ডেলিভারি',
    statuses: ['in_delivery', 'delivery_confirmed'],
  },
  { key: 'completed', label: 'সম্পন্ন', statuses: ['completed', 'rejected'] },
];

function AllDealsPanel() {
  const [deals, setDeals] = useState<DealRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<DealFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const fetchDeals = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/deals');
      if (res.ok) {
        const data = await res.json();
        setDeals(data);
      }
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDeals();
  }, [fetchDeals]);

  const filteredDeals = deals.filter((deal) => {
    const tab = dealFilterTabs.find((t) => t.key === activeFilter);
    const matchesStatus =
      !tab ||
      tab.statuses.length === 0 ||
      tab.statuses.includes(deal.status);
    const matchesSearch =
      !searchQuery ||
      deal.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div>
      {/* Header */}
      <div className="mb-5">
        <h2 className="text-lg font-bold text-foreground flex items-center justify-center sm:justify-start gap-2">
          <Handshake className="h-5 w-5 text-primary" />
          সকল ডিল
        </h2>
        <p className="mt-0.5 text-sm text-muted-foreground text-center sm:text-left">
          প্ল্যাটফর্মের সকল ডিলের সম্পূর্ণ তালিকা
        </p>
      </div>

      {/* Filter Tabs + Search */}
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap justify-center gap-2">
          {dealFilterTabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveFilter(tab.key)}
              className={`rounded-lg px-3.5 py-2 text-xs font-semibold transition-all ${
                activeFilter === tab.key
                  ? 'bg-primary text-primary-foreground shadow-md shadow-primary/20'
                  : 'bg-white text-muted-foreground border border-border hover:border-primary/30 hover:text-foreground dark:bg-zinc-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 rounded-lg border border-border bg-white px-3 py-2 dark:bg-zinc-800">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ডিল শিরোনাম দিয়ে খুঁজুন..."
            className="w-48 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
        </div>
      </div>

      {/* Table Card */}
      <SolidCard className="!p-0 overflow-hidden">
        {loading ? (
          <LoadingSpinner />
        ) : filteredDeals.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <CheckCircle className="mb-3 h-10 w-10 text-primary" />
            <p className="text-sm font-semibold text-foreground">
              কোনো ডিল পাওয়া যায়নি
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              এই ফিল্টারে কোনো ডিল নেই
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
            <table className="w-full text-sm min-w-[700px]">
              <thead className="sticky top-0 bg-white dark:bg-zinc-900 z-10">
                <tr className="border-b border-border bg-muted/30">
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    ডিল আইডি
                  </th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    ক্রেতা
                  </th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    বিক্রেতা
                  </th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    শিরোনাম
                  </th>
                  <th className="px-5 py-3 text-right text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    পরিমাণ
                  </th>
                  <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    স্ট্যাটাস
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredDeals.map((deal) => {
                  const shortId =
                    deal.id.length > 10
                      ? 'DL-' + deal.id.slice(-5)
                      : deal.id;
                  const buyerName = deal.buyer?.name || '—';
                  const sellerName = deal.seller?.name || 'অনির্ধারিত';

                  return (
                    <tr
                      key={deal.id}
                      className="border-b border-border/30 transition-colors hover:bg-muted/20 last:border-0"
                    >
                      <td className="px-5 py-4 font-mono text-xs text-muted-foreground whitespace-nowrap">
                        {shortId}
                      </td>
                      <td className="px-5 py-4 font-medium text-foreground whitespace-nowrap">
                        {buyerName}
                      </td>
                      <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">
                        {sellerName}
                      </td>
                      <td className="px-5 py-4 text-foreground max-w-[160px] truncate">
                        {deal.title}
                      </td>
                      <td className="px-5 py-4 text-right font-semibold text-foreground whitespace-nowrap">
                        ৳{deal.amount.toLocaleString('bn-BD')}
                      </td>
                      <td className="px-5 py-4 text-center whitespace-nowrap">
                        <StatusBadge status={deal.status} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </SolidCard>
    </div>
  );
}

/* ═══════════════════════════════════════════
   Panel 4: ইউজার ম্যানেজমেন্ট
   ═══════════════════════════════════════════ */

function UsersPanel() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [changingRole, setChangingRole] = useState<string | null>(null);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const fetchUsers = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        setUsers(data);
      }
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleChangeRole = async (userId: string, role: string) => {
    setChangingRole(userId);
    try {
      const res = await fetch('/api/admin/users/role', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, role }),
      });
      if (res.ok) {
        toast.success('ভূমিকা সফলভাবে পরিবর্তন হয়েছে');
        fetchUsers();
      } else {
        toast.error('ভূমিকা পরিবর্তন ব্যর্থ হয়েছে');
      }
    } catch {
      toast.error('সার্ভারে সমস্যা');
    } finally {
      setChangingRole(null);
      setOpenDropdown(null);
    }
  };

  const roles = ['user', 'seller', 'admin'];
  const roleLabels: Record<string, string> = {
    user: 'ইউজার',
    seller: 'বিক্রেতা',
    admin: 'অ্যাডমিন',
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-5">
        <h2 className="text-lg font-bold text-foreground flex items-center justify-center sm:justify-start gap-2">
          <Users className="h-5 w-5 text-primary" />
          ইউজার ম্যানেজমেন্ট
        </h2>
        <p className="mt-0.5 text-sm text-muted-foreground text-center sm:text-left">
          সকল নিবন্ধিত ইউজারের তালিকা ও ব্যবস্থাপনা
        </p>
      </div>

      {/* Table Card */}
      <SolidCard className="!p-0 overflow-hidden">
        {loading ? (
          <LoadingSpinner />
        ) : users.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Users className="mb-3 h-10 w-10 text-muted-foreground" />
            <p className="text-sm font-semibold text-foreground">
              কোনো ইউজার নেই
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              এখনো কোনো ইউজার নিবন্ধন করেনি
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
            <table className="w-full text-sm min-w-[700px]">
              <thead className="sticky top-0 bg-white dark:bg-zinc-900 z-10">
                <tr className="border-b border-border bg-muted/30">
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    নাম
                  </th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    ইমেইল
                  </th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    মোবাইল
                  </th>
                  <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    ভূমিকা
                  </th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    নিবন্ধনের তারিখ
                  </th>
                  <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    অ্যাকশন
                  </th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => {
                  const isChanging = changingRole === u.id;
                  const isOpen = openDropdown === u.id;

                  return (
                    <tr
                      key={u.id}
                      className="border-b border-border/30 transition-colors hover:bg-muted/20 last:border-0"
                    >
                      <td className="px-5 py-4 font-medium text-foreground whitespace-nowrap">
                        {u.name}
                      </td>
                      <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">
                        {u.email}
                      </td>
                      <td className="px-5 py-4 text-muted-foreground whitespace-nowrap">
                        {u.phone}
                      </td>
                      <td className="px-5 py-4 text-center whitespace-nowrap">
                        <RoleBadge role={u.role} />
                      </td>
                      <td className="px-5 py-4 text-muted-foreground whitespace-nowrap text-xs">
                        {new Date(u.createdAt).toLocaleDateString('bn-BD', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </td>
                      <td className="px-5 py-4 text-center whitespace-nowrap">
                        <div className="relative inline-block">
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={isChanging}
                            onClick={() =>
                              setOpenDropdown(isOpen ? null : u.id)
                            }
                            className="h-9 gap-1.5 rounded-lg text-xs font-medium"
                          >
                            {isChanging ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Settings className="h-3.5 w-3.5" />
                            )}
                            ভূমিকা পরিবর্তন
                            <ChevronDown className="h-3 w-3" />
                          </Button>
                          {isOpen && (
                            <motion.div
                              initial={{ opacity: 0, y: -4 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="absolute right-0 top-full z-20 mt-1 min-w-[140px] rounded-xl border border-border bg-white p-1.5 shadow-lg dark:bg-zinc-800"
                            >
                              {roles.map((role) => (
                                <button
                                  key={role}
                                  onClick={() => handleChangeRole(u.id, role)}
                                  disabled={u.role === role || isChanging}
                                  className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                                    u.role === role
                                      ? 'bg-primary/10 text-primary'
                                      : 'text-foreground hover:bg-muted'
                                  } disabled:opacity-50`}
                                >
                                  <RoleBadge role={role} />
                                  {roleLabels[role]}
                                </button>
                              ))}
                            </motion.div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </SolidCard>
    </div>
  );
}

/* ═══════════════════════════════════════════
   Panel 5: ওয়েবসাইট সেটিংস
   ═══════════════════════════════════════════ */

function SettingsPanel() {
  const [settings, setSettings] = useState<PlatformSettings>({
    platform_name: '',
    fee_percentage: '',
    min_deal_amount: '',
    max_deal_amount: '',
    support_number: '',
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await fetch('/api/admin/settings');
        if (res.ok) {
          const data = await res.json();
          setSettings(data);
        }
      } catch {
        // silent
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        toast.success('সেটিংস সফলভাবে সংরক্ষণ হয়েছে');
      } else {
        toast.error('সেটিংস সংরক্ষণ ব্যর্থ হয়েছে');
      }
    } catch {
      toast.error('সার্ভারে সমস্যা');
    } finally {
      setSaving(false);
    }
  };

  const fields: {
    key: keyof PlatformSettings;
    label: string;
    type: string;
    placeholder: string;
  }[] = [
    {
      key: 'platform_name',
      label: 'প্ল্যাটফর্মের নাম',
      type: 'text',
      placeholder: 'আমার ডিল',
    },
    {
      key: 'fee_percentage',
      label: 'ফি শতাংশ (%)',
      type: 'number',
      placeholder: '৩',
    },
    {
      key: 'min_deal_amount',
      label: 'ন্যূনতম ডিল পরিমাণ (৳)',
      type: 'number',
      placeholder: '১০০',
    },
    {
      key: 'max_deal_amount',
      label: 'সর্বোচ্চ ডিল পরিমাণ (৳)',
      type: 'number',
      placeholder: '১০০০০০০',
    },
    {
      key: 'support_number',
      label: 'সাপোর্ট নাম্বার',
      type: 'text',
      placeholder: '০১৭০০০০০০০০',
    },
  ];

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      {/* Header */}
      <div className="mb-5">
        <h2 className="text-lg font-bold text-foreground flex items-center justify-center sm:justify-start gap-2">
          <Settings className="h-5 w-5 text-primary" />
          ওয়েবসাইট সেটিংস
        </h2>
        <p className="mt-0.5 text-sm text-muted-foreground text-center sm:text-left">
          এসক্রো প্ল্যাটফর্মের সাধারণ কনফিগারেশন
        </p>
      </div>

      {/* Settings Form Card */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <SolidCard>
          <div className="space-y-5">
            {fields.map((field) => (
              <div
                key={field.key}
                className="grid grid-cols-1 gap-2 sm:grid-cols-[240px_1fr] sm:items-center"
              >
                <Label
                  htmlFor={field.key}
                  className="text-sm font-medium text-foreground text-center sm:text-left"
                >
                  {field.label}
                </Label>
                <Input
                  id={field.key}
                  type={field.type}
                  value={settings[field.key]}
                  onChange={(e) =>
                    setSettings({ ...settings, [field.key]: e.target.value })
                  }
                  placeholder={field.placeholder}
                  className="max-w-sm"
                />
              </div>
            ))}
          </div>

          <div className="mt-8 flex justify-center sm:justify-end">
            <Button
              onClick={handleSave}
              disabled={saving}
              className="h-10 gap-2 rounded-xl px-6 text-sm font-semibold shadow-md shadow-primary/20"
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              সেটিংস সংরক্ষণ করুন
            </Button>
          </div>
        </SolidCard>
      </motion.div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   Panel Router
   ═══════════════════════════════════════════ */

function AdminPanelContent({ panel }: { panel: AdminPanel }) {
  switch (panel) {
    case 'payment-verify':
      return <PaymentVerifyPanel />;
    case 'payment-methods':
      return <PaymentMethodsPanel />;
    case 'all-deals':
      return <AllDealsPanel />;
    case 'users':
      return <UsersPanel />;
    case 'settings':
      return <SettingsPanel />;
    default:
      return null;
  }
}

/* ═══════════════════════════════════════════
   Admin Main (Exported)
   ═══════════════════════════════════════════ */

export function AdminMain() {
  const { adminPanel, setSidebarOpen, user } = useAppStore();
  const mounted = useSyncExternalStore(emptySubscribe, () => true, () => false);

  if (!mounted) return null;

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8">
      {/* ── Top Bar ── */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Mobile Menu Button */}
          <button
            onClick={() => setSidebarOpen(true)}
            className="flex h-10 w-10 items-center justify-center rounded-xl text-muted-foreground hover:bg-accent hover:text-foreground transition-colors lg:hidden"
            aria-label="মেনু"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="text-center lg:text-left">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-foreground flex items-center justify-center lg:justify-start gap-2">
              <span className="text-primary">আমার ডিল</span>
              <span className="text-muted-foreground font-normal text-base">
                — অ্যাডমিন প্যানেল
              </span>
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              এসক্রো ম্যানেজমেন্ট ড্যাশবোর্ড
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Notification Bell */}
          <button
            className="relative flex h-10 w-10 items-center justify-center rounded-xl text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
            aria-label="নোটিফিকেশন"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-red-500" />
          </button>
          {/* Admin Avatar */}
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-sm font-bold text-primary">
            {user?.name?.charAt(0) || 'অ'}
          </div>
        </div>
      </div>

      {/* ── Stats Cards (Dashboard only) ── */}
      {adminPanel === 'dashboard' && (
        <div className="mb-6">
          <DashboardStatsPanel />
        </div>
      )}

      {/* ── Panel Content ── */}
      <AdminPanelContent panel={adminPanel} />
    </div>
  );
}