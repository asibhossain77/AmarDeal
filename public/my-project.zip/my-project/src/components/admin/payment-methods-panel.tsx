'use client';

import { useState, useEffect, useSyncExternalStore, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import {
  CreditCard,
  Plus,
  Pencil,
  Trash2,
  Save,
  X,
  Palette,
  Loader2,
  CheckCircle,
  Eye,
} from 'lucide-react';

const emptySubscribe = () => () => {};

/* ─── Types ─── */
interface PaymentMethod {
  id: string;
  name: string;
  accountNumber: string;
  accountType: string;
  status: string;
  sortOrder: number;
  createdAt: string;
}

interface FormData {
  name: string;
  accountNumber: string;
  accountType: string;
  status: string;
  sortOrder: number;
}

const emptyForm: FormData = {
  name: '',
  accountNumber: '',
  accountType: 'personal',
  status: 'active',
  sortOrder: 0,
};

/* ─── Solid Card Helper ─── */
function SolidCard({
  children,
  className = '',
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`rounded-2xl bg-white p-5 shadow-lg dark:bg-zinc-900 ${className}`}
    >
      {children}
    </div>
  );
}

/* ═══════════════════════════════════════════
   Admin Payment Methods Panel
   ═══════════════════════════════════════════ */

export function PaymentMethodsPanel() {
  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormData>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Theme color state
  const [themeColor, setThemeColor] = useState('#A3E635');
  const [originalThemeColor, setOriginalThemeColor] = useState('#A3E635');
  const [savingTheme, setSavingTheme] = useState(false);
  const [themeLoaded, setThemeLoaded] = useState(false);

  const fetchMethods = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/payment-methods');
      if (res.ok) setMethods(await res.json());
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchThemeColor = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/settings');
      if (res.ok) {
        const data = await res.json();
        if (data.payment_theme_color) {
          setThemeColor(data.payment_theme_color);
          setOriginalThemeColor(data.payment_theme_color);
        }
      }
    } catch {
      // silent
    } finally {
      setThemeLoaded(true);
    }
  }, []);

  useEffect(() => {
    fetchMethods();
    fetchThemeColor();
  }, [fetchMethods, fetchThemeColor]);

  // ─── CRUD Handlers ───
  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setDialogOpen(true);
  };

  const openEdit = (m: PaymentMethod) => {
    setEditingId(m.id);
    setForm({
      name: m.name,
      accountNumber: m.accountNumber,
      accountType: m.accountType,
      status: m.status,
      sortOrder: m.sortOrder,
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.accountNumber.trim()) {
      toast.error('নাম এবং অ্যাকাউন্ট নম্বর আবশ্যক');
      return;
    }
    setSaving(true);
    try {
      const url = editingId
        ? `/api/admin/payment-methods/${editingId}`
        : '/api/admin/payment-methods';
      const method = editingId ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        toast.success(editingId ? 'মেথড আপডেট হয়েছে' : 'নতুন মেথড যোগ হয়েছে');
        setDialogOpen(false);
        fetchMethods();
      } else {
        toast.error('সংরক্ষণ ব্যর্থ হয়েছে');
      }
    } catch {
      toast.error('সার্ভারে সমস্যা');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      const res = await fetch(`/api/admin/payment-methods/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        toast.success('মেথড মুছে ফেলা হয়েছে');
        fetchMethods();
      } else {
        toast.error('মুছে ফেলা ব্যর্থ হয়েছে');
      }
    } catch {
      toast.error('সার্ভারে সমস্যা');
    } finally {
      setDeletingId(null);
    }
  };

  const handleSaveTheme = async () => {
    setSavingTheme(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payment_theme_color: themeColor }),
      });
      if (res.ok) {
        setOriginalThemeColor(themeColor);
        toast.success('থিম কালার সংরক্ষণ হয়েছে');
      } else {
        toast.error('থিম সংরক্ষণ ব্যর্থ হয়েছে');
      }
    } catch {
      toast.error('সার্ভারে সমস্যা');
    } finally {
      setSavingTheme(false);
    }
  };

  const hasThemeChanged = themeColor !== originalThemeColor;

  // Preview methods for the color picker
  const previewMethods = ['bKash', 'Nagad', 'Rocket', 'Bank Transfer'];

  if (loading && !themeLoaded)
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );

  return (
    <div className="space-y-6">
      {/* ═══ Section 1: Payment Methods CRUD ═══ */}
      <div>
        {/* Header */}
        <div className="mb-5 flex flex-col items-center gap-3 sm:flex-row sm:justify-between">
          <div className="text-center sm:text-left">
            <h2 className="text-lg font-bold text-foreground flex items-center justify-center sm:justify-start gap-2">
              <CreditCard className="h-5 w-5 text-primary" />
              পেমেন্ট মেথড ম্যানেজমেন্ট
            </h2>
            <p className="mt-0.5 text-sm text-muted-foreground">
              পেমেন্ট মেথড তৈরি, সম্পাদনা ও মুছে ফেলুন
            </p>
          </div>
          <Button
            onClick={openCreate}
            className="h-9 gap-1.5 rounded-lg text-xs font-semibold shadow-md shadow-primary/20"
          >
            <Plus className="h-4 w-4" />
            নতুন মেথড যোগ করুন
          </Button>
        </div>

        {/* Table Card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <SolidCard className="!p-0 overflow-hidden">
            {loading ? (
              <div className="flex items-center justify-center py-16">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : methods.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <CreditCard className="mb-3 h-10 w-10 text-muted-foreground" />
                <p className="text-sm font-semibold text-foreground">
                  কোনো পেমেন্ট মেথড নেই
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  নতুন মেথড যোগ করতে উপরের বাটনে ক্লিক করুন
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm min-w-[700px]">
                  <thead className="sticky top-0 bg-white dark:bg-zinc-900 z-10">
                    <tr className="border-b border-border bg-muted/30">
                      <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                        মেথড নাম
                      </th>
                      <th className="px-5 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                        অ্যাকাউন্ট নম্বর
                      </th>
                      <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                        অ্যাকাউন্ট টাইপ
                      </th>
                      <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                        স্ট্যাটাস
                      </th>
                      <th className="px-5 py-3 text-center text-xs font-semibold text-muted-foreground whitespace-nowrap">
                        অ্যাকশন
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {methods.map((m) => (
                      <tr
                        key={m.id}
                        className="border-b border-border/30 transition-colors hover:bg-muted/20 last:border-0"
                      >
                        <td className="px-5 py-4 font-medium text-foreground whitespace-nowrap">
                          {m.name}
                        </td>
                        <td className="px-5 py-4 font-mono text-xs text-muted-foreground whitespace-nowrap">
                          {m.accountNumber}
                        </td>
                        <td className="px-5 py-4 text-center whitespace-nowrap">
                          {m.accountType === 'merchant' ? (
                            <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400 border-0 font-medium">
                              মার্চেন্ট
                            </Badge>
                          ) : (
                            <Badge className="bg-slate-100 text-slate-700 dark:bg-slate-500/15 dark:text-slate-400 border-0 font-medium">
                              পার্সোনাল
                            </Badge>
                          )}
                        </td>
                        <td className="px-5 py-4 text-center whitespace-nowrap">
                          {m.status === 'active' ? (
                            <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400 border-0 font-medium">
                              সক্রিয়
                            </Badge>
                          ) : (
                            <Badge className="bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400 border-0 font-medium">
                              নিষ্ক্রিয়
                            </Badge>
                          )}
                        </td>
                        <td className="px-5 py-4 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => openEdit(m)}
                              className="h-8 gap-1.5 rounded-lg text-xs font-medium"
                            >
                              <Pencil className="h-3.5 w-3.5" />
                              সম্পাদনা
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              disabled={deletingId === m.id}
                              onClick={() => handleDelete(m.id)}
                              className="h-8 gap-1.5 rounded-lg text-xs font-medium border-red-200 text-red-600 hover:bg-red-50 dark:border-red-800/50 dark:text-red-400 dark:hover:bg-red-500/10"
                            >
                              {deletingId === m.id ? (
                                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                              ) : (
                                <Trash2 className="h-3.5 w-3.5" />
                              )}
                              মুছুন
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </SolidCard>
        </motion.div>
      </div>

      {/* ═══ Section 2: Payment Theme Configuration ═══ */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.15 }}
      >
        <div className="mb-5 text-center sm:text-left">
          <h2 className="text-lg font-bold text-foreground flex items-center justify-center sm:justify-start gap-2">
            <Palette className="h-5 w-5 text-primary" />
            পেমেন্ট থিম কনফিগারেশন
          </h2>
          <p className="mt-0.5 text-sm text-muted-foreground">
            পেমেন্ট পেজের প্রাইমারি কালার কাস্টমাইজ করুন
          </p>
        </div>

        <SolidCard>
          <div className="space-y-6">
            {/* Color Picker Row */}
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <Label className="text-sm font-medium text-foreground">
                  প্রাইমারি পেমেন্ট থিম কালার
                </Label>
                <p className="mt-1 text-xs text-muted-foreground">
                  এই কালার পেমেন্ট পেজের সিলেকশন, বর্ডার এবং বাটনে প্রয়োগ হবে
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <input
                    type="color"
                    value={themeColor}
                    onChange={(e) => setThemeColor(e.target.value)}
                    className="h-10 w-14 cursor-pointer rounded-lg border border-border p-1 bg-transparent"
                  />
                </div>
                <Input
                  value={themeColor}
                  onChange={(e) => {
                    const v = e.target.value;
                    if (/^#[0-9a-fA-F]{0,6}$/.test(v)) {
                      setThemeColor(v.length === 7 ? v : themeColor);
                    }
                  }}
                  className="w-28 h-10 font-mono text-sm"
                />
                {hasThemeChanged && (
                  <span className="text-xs text-amber-600 dark:text-amber-400 font-medium whitespace-nowrap">
                    পরিবর্তিত
                  </span>
                )}
              </div>
            </div>

            {/* ─── Real-Time Preview ─── */}
            <div className="rounded-xl border border-border/50 bg-muted/30 p-4">
              <div className="mb-3 flex items-center gap-2">
                <Eye className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-semibold text-foreground">
                  রিয়েল-টাইম প্রিভিউ
                </span>
              </div>

              {/* Mini method selection grid */}
              <div className="mb-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
                {previewMethods.map((name, i) => {
                  const isSelected = i === 0;
                  return (
                    <button
                      key={name}
                      className="rounded-xl border-2 p-3 text-center transition-all text-xs font-medium"
                      style={{
                        borderColor: isSelected
                          ? themeColor
                          : 'hsl(var(--border))',
                        backgroundColor: isSelected
                          ? `${themeColor}15`
                          : 'transparent',
                        color: isSelected ? themeColor : 'hsl(var(--foreground))',
                      }}
                    >
                      <div
                        className="mx-auto mb-1.5 h-8 w-8 rounded-lg flex items-center justify-center"
                        style={{
                          backgroundColor: `${themeColor}20`,
                        }}
                      >
                        <CreditCard
                          className="h-4 w-4"
                          style={{ color: themeColor }}
                        />
                      </div>
                      {name}
                    </button>
                  );
                })}
              </div>

              {/* Mini instructions box */}
              <div
                className="mb-4 rounded-xl border-l-4 bg-white dark:bg-zinc-800 p-3"
                style={{ borderLeftColor: themeColor }}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">মোট পরিমাণ</span>
                  <span className="font-bold" style={{ color: themeColor }}>
                    ৳১,০৩,০০০.০০
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs mt-1">
                  <span className="text-muted-foreground">পেমেন্ট পাঠান</span>
                  <span className="font-mono font-medium text-foreground">
                    ০১৭XXXXXXXXX
                  </span>
                </div>
              </div>

              {/* Mini confirm button */}
              <button
                className="w-full h-10 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-transform hover:scale-[1.01] active:scale-[0.99]"
                style={{
                  backgroundColor: themeColor,
                  color: getContrastColor(themeColor),
                }}
              >
                <ShieldCheckIcon />
                কনফার্ম পেমেন্ট
              </button>
            </div>

            {/* Save Theme Button */}
            <div className="flex justify-end">
              <Button
                onClick={handleSaveTheme}
                disabled={savingTheme || !hasThemeChanged}
                className="h-10 gap-2 rounded-xl px-6 text-sm font-semibold shadow-md shadow-primary/20"
              >
                {savingTheme ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                থিম সংরক্ষণ করুন
              </Button>
            </div>
          </div>
        </SolidCard>
      </motion.div>

      {/* ═══ Add/Edit Dialog ═══ */}
      <AnimatePresence>
        {dialogOpen && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
              onClick={() => setDialogOpen(false)}
            />
            {/* Modal */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 16 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
            >
              <div
                className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl dark:bg-zinc-900"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Modal Header */}
                <div className="mb-5 flex items-center justify-between">
                  <h3 className="text-base font-bold text-foreground">
                    {editingId ? 'মেথড সম্পাদনা করুন' : 'নতুন মেথড যোগ করুন'}
                  </h3>
                  <button
                    onClick={() => setDialogOpen(false)}
                    className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                {/* Modal Form */}
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <Label className="text-sm font-medium">মেথড নাম</Label>
                    <Input
                      value={form.name}
                      onChange={(e) =>
                        setForm({ ...form, name: e.target.value })
                      }
                      placeholder="যেমন: bKash, Nagad, Rocket"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <Label className="text-sm font-medium">
                      অ্যাকাউন্ট নম্বর
                    </Label>
                    <Input
                      value={form.accountNumber}
                      onChange={(e) =>
                        setForm({ ...form, accountNumber: e.target.value })
                      }
                      placeholder="০১XXXXXXXXX"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">
                        অ্যাকাউন্ট টাইপ
                      </Label>
                      <select
                        value={form.accountType}
                        onChange={(e) =>
                          setForm({ ...form, accountType: e.target.value })
                        }
                        className="flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                      >
                        <option value="personal">পার্সোনাল</option>
                        <option value="merchant">মার্চেন্ট</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">স্ট্যাটাস</Label>
                      <select
                        value={form.status}
                        onChange={(e) =>
                          setForm({ ...form, status: e.target.value })
                        }
                        className="flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                      >
                        <option value="active">সক্রিয়</option>
                        <option value="inactive">নিষ্ক্রিয়</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <Label className="text-sm font-medium">সর্ট অর্ডার</Label>
                    <Input
                      type="number"
                      value={form.sortOrder}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          sortOrder: parseInt(e.target.value) || 0,
                        })
                      }
                      placeholder="০"
                    />
                    <p className="text-xs text-muted-foreground">
                      কম মান মানে পেমেন্ট পেজে আগে দেখাবে
                    </p>
                  </div>
                </div>

                {/* Modal Actions */}
                <div className="mt-6 flex items-center justify-end gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setDialogOpen(false)}
                    className="h-10 rounded-xl px-5 text-sm font-medium"
                  >
                    বাতিল
                  </Button>
                  <Button
                    onClick={handleSave}
                    disabled={saving}
                    className="h-10 gap-2 rounded-xl px-5 text-sm font-semibold shadow-md shadow-primary/20"
                  >
                    {saving ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    সংরক্ষণ করুন
                  </Button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─── Helpers ─── */
function getContrastColor(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.6 ? '#18181b' : '#ffffff';
}

function ShieldCheckIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}